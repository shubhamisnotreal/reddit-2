"use client"

import { Suspense, useEffect, useState } from "react"
import { PostFeed } from "@/components/post-feed"
import { CreatePostCard } from "@/components/create-post-card"
import { Sidebar } from "@/components/sidebar"
import { TrendingTopics } from "@/components/trending-topics"
import { SortingTabs } from "@/components/sorting-tabs"
import { PostSkeleton } from "@/components/post-skeleton"

// Initial posts data from all communities
const initialPosts = [
  {
    id: "react-1",
    title: "🚀 Just launched my React app and it got featured on Product Hunt!",
    content:
      "After 6 months of development, my side project just hit #1 on Product Hunt! The response has been incredible - 2000+ upvotes, 500+ comments, and 50+ new users in the first hour. This community has been so supportive throughout my journey. Thank you all!",
    author: "startup_founder",
    subreddit: "reactjs",
    votes: 2847,
    comments: 234,
    timeAgo: "3 hours ago",
    awards: [
      { type: "rocket", count: 12, icon: "🚀" },
      { type: "helpful", count: 8, icon: "🙋" },
      { type: "gold", count: 3, icon: "🥇" },
    ],
    image: "/images/react-app-dashboard.png",
    flair: "Success Story",
    views: 15420,
    sortScore: { hot: 95, new: 70, top: 85, rising: 90, controversial: 20 },
    createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
  },
  {
    id: "security-1",
    title: "🔥 Breaking: Major security vulnerability found in popular npm package",
    content:
      "URGENT: A critical security flaw has been discovered in the 'popular-utils' npm package (50M+ weekly downloads). The vulnerability allows remote code execution. Update to version 2.1.4 immediately. CVE-2024-1234 has been assigned.",
    author: "security_researcher",
    subreddit: "programming",
    votes: 4521,
    comments: 387,
    timeAgo: "2 hours ago",
    awards: [
      { type: "helpful", count: 25, icon: "🙋" },
      { type: "important", count: 15, icon: "⚠️" },
    ],
    image: "/images/security-vulnerability.png",
    flair: "Security Alert",
    isPinned: true,
    views: 28750,
    sortScore: { hot: 98, new: 80, top: 95, rising: 85, controversial: 15 },
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
  },
  {
    id: "design-1",
    title: "📱 First look at my new mobile app design - thoughts?",
    content:
      "I've been working on this fitness tracking app design for the past week. It's my first attempt at mobile UI/UX. I'd love to get some feedback from the community before I start development. What do you think about the color scheme and layout?",
    author: "design_newbie",
    subreddit: "design",
    votes: 23,
    comments: 8,
    timeAgo: "15 minutes ago",
    awards: [],
    image: "/images/mobile-app-mockup.png",
    flair: "Feedback",
    views: 156,
    sortScore: { hot: 25, new: 100, top: 15, rising: 30, controversial: 10 },
    createdAt: new Date(Date.now() - 15 * 60 * 1000),
  },
  {
    id: "gamedev-1",
    title: "🎮 Just finished my first game in Unity - a simple platformer",
    content:
      "After following tutorials for months, I finally completed my first game! It's a basic 2D platformer with 5 levels. The graphics are simple but I'm proud of the mechanics I implemented. Planning to add more levels and maybe publish it. Any Unity developers here with advice?",
    author: "indie_dev_2024",
    subreddit: "gamedev",
    votes: 67,
    comments: 12,
    timeAgo: "45 minutes ago",
    awards: [{ type: "wholesome", count: 2, icon: "🤗" }],
    image: "/images/unity-platformer.png",
    flair: "First Game",
    views: 289,
    sortScore: { hot: 35, new: 95, top: 25, rising: 45, controversial: 5 },
    createdAt: new Date(Date.now() - 45 * 60 * 1000),
  },
  {
    id: "webdev-1",
    title: "🏆 I recreated the entire Reddit homepage using only CSS Grid and Flexbox",
    content:
      "Challenge accepted! Someone on Twitter said it was impossible to recreate Reddit's complex layout using only CSS Grid and Flexbox (no JavaScript for layout). Took me 3 days, but here's the result. Fully responsive, pixel-perfect, and the code is surprisingly clean. Source code in comments!",
    author: "css_wizard",
    subreddit: "webdev",
    votes: 8934,
    comments: 456,
    timeAgo: "1 day ago",
    awards: [
      { type: "gold", count: 15, icon: "🥇" },
      { type: "genius", count: 8, icon: "🧠" },
      { type: "helpful", count: 32, icon: "🙋" },
    ],
    image: "/images/css-grid-layout.png",
    flair: "CSS Magic",
    views: 45230,
    sortScore: { hot: 75, new: 40, top: 100, rising: 20, controversial: 25 },
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
  },
]

export default function HomePage() {
  const [mounted, setMounted] = useState(false)
  const [currentSort, setCurrentSort] = useState("all")
  const [posts, setPosts] = useState(initialPosts)

  useEffect(() => {
    setMounted(true)

    // Apply compact view if saved in localStorage
    const savedCompactView = localStorage.getItem("compactView")
    if (savedCompactView === "true") {
      document.body.classList.add("compact-view")
    }

    // Listen for sort changes
    const handleSortChange = (event: CustomEvent) => {
      setCurrentSort(event.detail.sortType)
    }

    window.addEventListener("sortChange", handleSortChange as EventListener)

    // Check URL for initial sort
    const urlParams = new URLSearchParams(window.location.search)
    const sortParam = urlParams.get("sort")
    if (sortParam) {
      setCurrentSort(sortParam)
    }

    return () => {
      window.removeEventListener("sortChange", handleSortChange as EventListener)
    }
  }, [])

  const addNewPost = (newPostData: any) => {
    const newPost = {
      id: `user-post-${Date.now()}`,
      ...newPostData,
      author: "john_doe", // Current user
      votes: 1,
      comments: 0,
      timeAgo: "just now",
      awards: [],
      views: 1,
      sortScore: { hot: 50, new: 100, top: 1, rising: 80, controversial: 10 },
      createdAt: new Date(),
    }

    // Add the new post to the beginning of the posts array
    setPosts((prevPosts) => [newPost, ...prevPosts])

    // Store user posts in localStorage for profile page
    const userPosts = JSON.parse(localStorage.getItem("userPosts") || "[]")
    userPosts.unshift(newPost)
    localStorage.setItem("userPosts", JSON.stringify(userPosts))

    // Show success message
    const postTypeText = newPostData.image ? "image post" : newPostData.url ? "link post" : "text post"
    console.log(`New ${postTypeText} created successfully!`)
  }

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            <CreatePostCard onPostCreate={addNewPost} />
            <SortingTabs onSortChange={setCurrentSort} />
            <Suspense fallback={<PostSkeleton />}>
              <PostFeed sortBy={currentSort} posts={posts} />
            </Suspense>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <TrendingTopics />
            <Sidebar />
          </div>
        </div>
      </div>
    </div>
  )
}
