"use client"

import type React from "react"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PostCard } from "@/components/post-card"
import { Search, Filter, Users, MessageSquare } from "lucide-react"

export default function SearchPage() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get("q") || ""

  const [searchQuery, setSearchQuery] = useState(initialQuery)
  const [activeTab, setActiveTab] = useState("posts")
  const [sortBy, setSortBy] = useState("relevance")

  // Mock search results
  const searchResults = {
    posts: [
      {
        id: "search-1",
        title: "🚀 Advanced React patterns and best practices",
        content: "Deep dive into React patterns including render props, compound components, and custom hooks...",
        author: "react_expert",
        subreddit: "reactjs",
        votes: 2341,
        comments: 156,
        timeAgo: "6 hours ago",
        awards: [{ type: "helpful", count: 8, icon: "🙋" }],
        flair: "Tutorial",
        views: 12450,
      },
      // Add more mock results...
    ],
    communities: [
      { name: "reactjs", members: "2.1M", description: "A community for learning React", joined: false },
      { name: "javascript", members: "3.2M", description: "JavaScript programming", joined: true },
    ],
    users: [
      { username: "react_guru", karma: "15.2k", description: "React developer and teacher" },
      { username: "js_master", karma: "8.9k", description: "Full-stack JavaScript developer" },
    ],
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Update URL and trigger search
    const url = new URL(window.location.href)
    url.searchParams.set("q", searchQuery)
    window.history.pushState({}, "", url.toString())

    console.log(`Searching for: ${searchQuery}`)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Search Header */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0 mb-6">
          <CardContent className="p-6">
            <form onSubmit={handleSearch} className="flex space-x-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search Reddit"
                  className="pl-10 py-3 text-lg"
                />
              </div>
              <Button
                type="submit"
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 px-8"
              >
                Search
              </Button>
            </form>

            {initialQuery && (
              <div className="mt-4 flex items-center justify-between">
                <p className="text-gray-600">
                  Search results for <span className="font-semibold">"{initialQuery}"</span>
                </p>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4 mr-2" />
                    Filters
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Search Results */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm shadow-lg border-0 mb-6">
            <TabsTrigger
              value="posts"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              Posts
            </TabsTrigger>
            <TabsTrigger
              value="communities"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              Communities
            </TabsTrigger>
            <TabsTrigger
              value="users"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              Users
            </TabsTrigger>
            <TabsTrigger
              value="comments"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              Comments
            </TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="space-y-6">
            {searchResults.posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </TabsContent>

          <TabsContent value="communities">
            <div className="grid gap-4">
              {searchResults.communities.map((community) => (
                <Card key={community.name} className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                          r/
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold">r/{community.name}</h3>
                          <p className="text-gray-600">{community.description}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Users className="w-4 h-4 text-gray-500" />
                            <span className="text-sm text-gray-500">{community.members} members</span>
                          </div>
                        </div>
                      </div>
                      <Button
                        variant={community.joined ? "outline" : "default"}
                        className={
                          !community.joined
                            ? "bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                            : ""
                        }
                      >
                        {community.joined ? "Joined" : "Join"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="users">
            <div className="grid gap-4">
              {searchResults.users.map((user) => (
                <Card key={user.username} className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center text-white font-bold">
                          {user.username[0].toUpperCase()}
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold">u/{user.username}</h3>
                          <p className="text-gray-600">{user.description}</p>
                          <p className="text-sm text-gray-500">{user.karma} karma</p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline">
                          <MessageSquare className="w-4 h-4 mr-2" />
                          Message
                        </Button>
                        <Button className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600">
                          Follow
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="comments">
            <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
              <CardContent className="p-6 text-center">
                <MessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600">Comment search results would appear here</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
