import { UserProfile } from "@/components/user-profile"

export default function UserPage({ params }: { params: { username: string } }) {
  // Check if this is the current user's profile
  // In a real app, you'd compare with the authenticated user's username
  const isOwnProfile = params.username === "john_doe"

  return <UserProfile isOwnProfile={isOwnProfile} />
}
