import { PostFeed } from "@/components/post-feed"
import { CreatePostCard } from "@/components/create-post-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, Calendar, Info } from "lucide-react"

export default function SubredditPage({ params }: { params: { subreddit: string } }) {
  // Mock subreddit data with realistic numbers for a new platform
  const subredditInfo = {
    name: params.subreddit,
    description: "A growing community for learning and developing web applications using React.",
    members: "2.1k",
    online: "89",
    created: "Aug 15, 2024",
    icon: "⚛️",
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Subreddit Header */}
      <div className="bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-center space-x-4">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center text-4xl">
              {subredditInfo.icon}
            </div>
            <div>
              <h1 className="text-3xl font-bold">r/{subredditInfo.name}</h1>
              <p className="text-blue-100 mt-1">{subredditInfo.description}</p>
              <div className="flex items-center space-x-4 mt-2 text-sm">
                <span className="flex items-center space-x-1">
                  <Users className="w-4 h-4" />
                  <span>{subredditInfo.members} members</span>
                </span>
                <span className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>{subredditInfo.online} online</span>
                </span>
                <span className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>Created {subredditInfo.created}</span>
                </span>
              </div>
            </div>
            <div className="ml-auto">
              <Button className="bg-white text-blue-600 hover:bg-gray-100">Join</Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-4">
            <CreatePostCard />
            <PostFeed />
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Info className="w-5 h-5" />
                  <span>About Community</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">{subredditInfo.description}</p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Members</span>
                    <span className="font-medium">{subredditInfo.members}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Online</span>
                    <span className="font-medium text-green-600">{subredditInfo.online}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Created</span>
                    <span className="font-medium">{subredditInfo.created}</span>
                  </div>
                </div>
                <Button className="w-full">Create Post</Button>
              </CardContent>
            </Card>

            {/* Rules */}
            <Card>
              <CardHeader>
                <CardTitle>Community Guidelines</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  "Be respectful and civil",
                  "No spam or self-promotion",
                  "Use descriptive titles",
                  "No duplicate posts",
                  "Follow platform guidelines",
                ].map((rule, index) => (
                  <div key={index} className="flex items-start space-x-2 text-sm">
                    <span className="font-medium text-gray-500">{index + 1}.</span>
                    <span className="text-gray-700">{rule}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
