import { NextResponse } from "next/server"

// Mock comments data
const comments = [
  {
    id: "1",
    postId: "1",
    author: "tech_enthusiast",
    content: "This is exactly what I needed! Great explanation.",
    votes: 42,
    timeAgo: "2 hours ago",
    parentId: null,
    createdAt: new Date().toISOString(),
  },
  // Add more comments...
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const postId = searchParams.get("postId")

  const postComments = comments.filter((comment) => comment.postId === postId)

  return NextResponse.json(postComments)
}

export async function POST(request: Request) {
  const body = await request.json()

  const newComment = {
    id: Date.now().toString(),
    ...body,
    votes: 1,
    timeAgo: "just now",
    createdAt: new Date().toISOString(),
  }

  comments.push(newComment)

  return NextResponse.json(newComment, { status: 201 })
}
