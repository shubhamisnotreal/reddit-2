import { NextResponse } from "next/server"

// Mock data - in real app, this would come from a database
const posts = [
  {
    id: "1",
    title: "Just finished building my first React app!",
    content: "After months of learning, I finally built something I'm proud of.",
    author: "newbie_dev",
    subreddit: "reactjs",
    votes: 1247,
    comments: 89,
    timeAgo: "4 hours ago",
    awards: 3,
    createdAt: new Date().toISOString(),
  },
  // Add more posts...
]

export async function GET() {
  return NextResponse.json(posts)
}

export async function POST(request: Request) {
  const body = await request.json()

  const newPost = {
    id: Date.now().toString(),
    ...body,
    votes: 1,
    comments: 0,
    awards: 0,
    timeAgo: "just now",
    createdAt: new Date().toISOString(),
  }

  posts.unshift(newPost)

  return NextResponse.json(newPost, { status: 201 })
}
