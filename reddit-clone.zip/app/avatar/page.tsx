"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Crown } from "lucide-react"
import Link from "next/link"

export default function AvatarPage() {
  const [selectedCategory, setSelectedCategory] = useState("hair")
  const [avatar, setAvatar] = useState({
    hair: "default",
    face: "default",
    clothing: "default",
    accessories: "none",
  })

  const categories = [
    { id: "hair", label: "Hair", icon: "💇" },
    { id: "face", label: "Face", icon: "😊" },
    { id: "clothing", label: "Clothing", icon: "👕" },
    { id: "accessories", label: "Accessories", icon: "👓" },
  ]

  const items = {
    hair: [
      { id: "default", name: "Default", premium: false },
      { id: "curly", name: "Curly", premium: false },
      { id: "long", name: "Long", premium: true },
      { id: "spiky", name: "Spiky", premium: true },
    ],
    face: [
      { id: "default", name: "Default", premium: false },
      { id: "beard", name: "Beard", premium: false },
      { id: "mustache", name: "Mustache", premium: true },
    ],
    clothing: [
      { id: "default", name: "T-Shirt", premium: false },
      { id: "hoodie", name: "Hoodie", premium: false },
      { id: "suit", name: "Suit", premium: true },
    ],
    accessories: [
      { id: "none", name: "None", premium: false },
      { id: "glasses", name: "Glasses", premium: false },
      { id: "hat", name: "Hat", premium: true },
    ],
  }

  const handleItemSelect = (category: string, itemId: string) => {
    setAvatar((prev) => ({ ...prev, [category]: itemId }))
  }

  const handleSave = () => {
    console.log("Saving avatar:", avatar)
    alert("Avatar saved successfully!")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-purple-50 to-pink-50">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="flex items-center space-x-2 mb-4">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Home</span>
            </Button>
          </Link>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
            Avatar Customization
          </h1>
          <p className="text-gray-600 mt-2">Customize your Reddit avatar</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Avatar Preview */}
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
            <CardHeader>
              <CardTitle className="text-center">Preview</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center space-y-4">
              <Avatar className="w-32 h-32 ring-4 ring-purple-200">
                <AvatarImage src="/placeholder-user.jpg" />
                <AvatarFallback className="text-4xl bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                  JD
                </AvatarFallback>
              </Avatar>
              <div className="text-center">
                <h3 className="font-semibold">john_doe</h3>
                <p className="text-sm text-gray-500">1,247 karma</p>
              </div>
              <Button
                onClick={handleSave}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                Save Avatar
              </Button>
            </CardContent>
          </Card>

          {/* Categories */}
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
            <CardHeader>
              <CardTitle>Categories</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "ghost"}
                  className={`w-full justify-start ${
                    selectedCategory === category.id ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white" : ""
                  }`}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <span className="mr-2">{category.icon}</span>
                  {category.label}
                </Button>
              ))}
            </CardContent>
          </Card>

          {/* Items */}
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
            <CardHeader>
              <CardTitle className="capitalize">{selectedCategory} Options</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {items[selectedCategory as keyof typeof items]?.map((item) => (
                <div
                  key={item.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    avatar[selectedCategory as keyof typeof avatar] === item.id
                      ? "border-purple-500 bg-purple-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => handleItemSelect(selectedCategory, item.id)}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{item.name}</span>
                    {item.premium && (
                      <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                        <Crown className="w-3 h-3 mr-1" />
                        Premium
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
