import { Suspense } from "react"
import { PostFeed } from "@/components/post-feed"
import { CreatePostCard } from "@/components/create-post-card"
import { Sidebar } from "@/components/sidebar"
import { TrendingTopics } from "@/components/trending-topics"
import { SortingTabs } from "@/components/sorting-tabs"
import { PostSkeleton } from "@/components/post-skeleton"

export default function AllPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
            All Posts
          </h1>
          <p className="text-gray-600 mt-2">Posts from all communities on Reddit</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            <CreatePostCard />
            <SortingTabs />
            <Suspense fallback={<PostSkeleton />}>
              <PostFeed />
            </Suspense>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <TrendingTopics />
            <Sidebar />
          </div>
        </div>
      </div>
    </div>
  )
}
