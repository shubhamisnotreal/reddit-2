"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Crown, Check, Star, Zap, Shield, Gift, Coins } from "lucide-react"

export default function PremiumPage() {
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "yearly">("monthly")

  const features = [
    { icon: Shield, title: "Ad-free browsing", description: "Browse Reddit without any advertisements" },
    { icon: Crown, title: "Exclusive awards", description: "Give premium awards to posts and comments" },
    { icon: Star, title: "Premium communities", description: "Access to exclusive premium subreddits" },
    { icon: Coins, title: "Monthly coins", description: "700 coins every month to give awards" },
    { icon: Gift, title: "Premium avatar gear", description: "Exclusive avatar items and customizations" },
    { icon: Zap, title: "Enhanced features", description: "Early access to new Reddit features" },
  ]

  const plans = {
    monthly: { price: 5.99, period: "month", savings: null },
    yearly: { price: 49.99, period: "year", savings: "Save 30%" },
  }

  const handleSubscribe = () => {
    const plan = plans[selectedPlan]
    console.log(`Subscribing to ${selectedPlan} plan: $${plan.price}/${plan.period}`)
    alert(`Redirecting to payment for ${selectedPlan} plan...`)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-orange-50 to-red-50">
      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center shadow-xl">
            <Crown className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent mb-4">
            Reddit Premium
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Upgrade your Reddit experience with premium features, exclusive content, and an ad-free browsing experience.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <Card
                key={index}
                className="bg-white/80 backdrop-blur-sm shadow-lg border-0 hover:shadow-xl transition-all"
              >
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 mx-auto mb-4 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Pricing */}
        <Card className="bg-white/90 backdrop-blur-sm shadow-2xl border-0 max-w-2xl mx-auto">
          <CardHeader className="text-center pb-6">
            <CardTitle className="text-2xl font-bold">Choose Your Plan</CardTitle>
            <p className="text-gray-600">Start your premium experience today</p>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Plan Toggle */}
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setSelectedPlan("monthly")}
                className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all ${
                  selectedPlan === "monthly" ? "bg-white shadow-sm text-gray-900" : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setSelectedPlan("yearly")}
                className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all relative ${
                  selectedPlan === "yearly" ? "bg-white shadow-sm text-gray-900" : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Yearly
                {plans.yearly.savings && (
                  <Badge className="absolute -top-2 -right-2 bg-green-500 text-white text-xs">
                    {plans.yearly.savings}
                  </Badge>
                )}
              </button>
            </div>

            {/* Selected Plan Details */}
            <div className="text-center py-6 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg">
              <div className="text-4xl font-bold text-gray-900 mb-2">
                ${plans[selectedPlan].price}
                <span className="text-lg font-normal text-gray-600">/{plans[selectedPlan].period}</span>
              </div>
              {selectedPlan === "yearly" && (
                <p className="text-green-600 font-medium">Save $22 compared to monthly billing</p>
              )}
            </div>

            {/* Features List */}
            <div className="space-y-3">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-700">{feature.title}</span>
                </div>
              ))}
            </div>

            {/* Subscribe Button */}
            <Button
              onClick={handleSubscribe}
              className="w-full py-4 text-lg bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 shadow-lg hover:shadow-xl transition-all"
            >
              <Crown className="w-5 h-5 mr-2" />
              Start Premium - ${plans[selectedPlan].price}/{plans[selectedPlan].period}
            </Button>

            <p className="text-center text-sm text-gray-500">
              Cancel anytime. No commitments. 30-day money-back guarantee.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
