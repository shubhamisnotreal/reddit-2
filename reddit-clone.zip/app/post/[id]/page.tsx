import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { PostCard } from "@/components/post-card"
import { CommentSection } from "@/components/comment-section"

export default function PostPage({ params }: { params: { id: string } }) {
  // Mock post data - in real app, fetch based on params.id
  const post = {
    id: params.id,
    title: "Just finished building my first React app! Any feedback would be appreciated.",
    content:
      "After months of learning, I finally built something I'm proud of. It's a simple todo app but it taught me so much about state management and component lifecycle. The journey wasn't easy - I struggled with understanding hooks at first, especially useEffect and its dependency array. But after building several small projects and reading the documentation multiple times, things started clicking. I also learned about proper component composition and how to structure a React application. Would love to hear your thoughts and any suggestions for improvement!",
    author: "newbie_dev",
    subreddit: "reactjs",
    votes: 1247,
    comments: 89,
    timeAgo: "4 hours ago",
    awards: [
      { type: "helpful", count: 3, icon: "🙋" },
      { type: "wholesome", count: 2, icon: "🤗" },
      { type: "silver", count: 1, icon: "🥈" },
    ],
    image: "/placeholder.svg?height=400&width=800",
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="mb-4">
          <Link href="/">
            <Button variant="ghost" className="flex items-center space-x-2">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Home</span>
            </Button>
          </Link>
        </div>

        <PostCard post={post} />
        <CommentSection />
      </div>
    </div>
  )
}
