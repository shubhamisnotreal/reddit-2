"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { MessageSquare, Send, Search, Plus } from "lucide-react"
import { MessageDialog } from "@/components/message-dialog"

interface Message {
  id: string
  from: string
  to: string
  subject: string
  content: string
  timestamp: string
  read: boolean
}

export function MessageCenter() {
  const [messages, setMessages] = useState<Message[]>([])
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null)
  const [replyText, setReplyText] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    // Load messages from localStorage
    const savedMessages = JSON.parse(localStorage.getItem("userMessages") || "[]")
    setMessages(savedMessages)
  }, [])

  const unreadCount = messages.filter((m) => !m.read && m.to === "john_doe").length

  const markAsRead = (id: string) => {
    const updatedMessages = messages.map((m) => (m.id === id ? { ...m, read: true } : m))
    setMessages(updatedMessages)
    localStorage.setItem("userMessages", JSON.stringify(updatedMessages))
  }

  const sendReply = () => {
    if (!replyText.trim() || !selectedMessage) return

    const replyMessage: Message = {
      id: Date.now().toString(),
      from: "john_doe",
      to: selectedMessage.from,
      subject: `Re: ${selectedMessage.subject}`,
      content: replyText,
      timestamp: new Date().toISOString(),
      read: false,
    }

    const updatedMessages = [...messages, replyMessage]
    setMessages(updatedMessages)
    localStorage.setItem("userMessages", JSON.stringify(updatedMessages))

    setReplyText("")
    showToast("Reply sent!")
  }

  const showToast = (message: string) => {
    const toast = document.createElement("div")
    toast.className =
      "fixed top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg z-50 transition-all duration-300"
    toast.textContent = message
    document.body.appendChild(toast)

    setTimeout(() => {
      toast.style.transform = "translateX(100%)"
      toast.style.opacity = "0"
      setTimeout(() => {
        if (document.body.contains(toast)) {
          document.body.removeChild(toast)
        }
      }, 300)
    }, 3000)
  }

  const filteredMessages = messages
    .filter((m) => m.to === "john_doe") // Only show messages sent to current user
    .filter(
      (m) =>
        m.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.content.toLowerCase().includes(searchQuery.toLowerCase()),
    )

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="relative hover:bg-orange-50 transition-all">
          <MessageSquare className="w-5 h-5" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center text-xs bg-gradient-to-r from-orange-500 to-red-500 animate-pulse">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle>Messages</DialogTitle>
          <div className="flex items-center space-x-2">
            <MessageDialog>
              <Button
                size="sm"
                className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Message
              </Button>
            </MessageDialog>
          </div>
        </DialogHeader>

        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search messages..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Message List */}
          <div className="w-1/2 border-r overflow-y-auto">
            {filteredMessages.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No messages found</p>
                <MessageDialog>
                  <Button variant="outline" size="sm" className="mt-2">
                    Send your first message
                  </Button>
                </MessageDialog>
              </div>
            ) : (
              filteredMessages.map((message) => (
                <div
                  key={message.id}
                  className={`p-3 border-b cursor-pointer hover:bg-gray-50 transition-colors ${
                    selectedMessage?.id === message.id ? "bg-blue-50 border-blue-200" : ""
                  } ${!message.read ? "bg-orange-50" : ""}`}
                  onClick={() => {
                    setSelectedMessage(message)
                    if (!message.read) {
                      markAsRead(message.id)
                    }
                  }}
                >
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src="/placeholder-user.jpg" />
                      <AvatarFallback>{message.from[0].toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-gray-900 truncate">u/{message.from}</p>
                        {!message.read && <div className="w-2 h-2 bg-orange-500 rounded-full"></div>}
                      </div>
                      <p className="text-sm font-medium text-gray-700 truncate">{message.subject}</p>
                      <p className="text-sm text-gray-600 truncate">{message.content}</p>
                      <p className="text-xs text-gray-500">{new Date(message.timestamp).toLocaleDateString()}</p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Message Detail */}
          <div className="w-1/2 flex flex-col">
            {selectedMessage ? (
              <>
                <div className="p-4 border-b">
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src="/placeholder-user.jpg" />
                      <AvatarFallback>{selectedMessage.from[0].toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">u/{selectedMessage.from}</p>
                      <p className="text-sm text-gray-500">{new Date(selectedMessage.timestamp).toLocaleString()}</p>
                    </div>
                  </div>
                  <h3 className="font-semibold mt-2">{selectedMessage.subject}</h3>
                </div>

                <div className="flex-1 p-4 overflow-y-auto">
                  <p className="text-gray-700 whitespace-pre-wrap">{selectedMessage.content}</p>
                </div>

                <div className="p-4 border-t">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Type your reply..."
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && sendReply()}
                      className="flex-1"
                    />
                    <Button onClick={sendReply} disabled={!replyText.trim()}>
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Select a message to view</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
