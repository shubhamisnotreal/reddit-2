"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { TrendingUp, Clock, Award, Zap, MapPin, Globe } from "lucide-react"

const sortOptions = [
  { id: "all", label: "All", icon: Globe, description: "Posts from all communities" },
  { id: "best", label: "Best", icon: TrendingUp, description: "Best posts based on quality" },
  { id: "hot", label: "Hot", icon: TrendingUp, description: "Posts that are trending" },
  { id: "new", label: "New", icon: Clock, description: "Newest posts first" },
  { id: "top", label: "Top", icon: Award, description: "Highest voted posts" },
  { id: "rising", label: "Rising", icon: Zap, description: "Posts gaining traction" },
  { id: "controversial", label: "Controversial", icon: MapPin, description: "Most debated posts" },
]

interface SortingTabsProps {
  onSortChange?: (sortType: string) => void
}

export function SortingTabs({ onSortChange }: SortingTabsProps) {
  const [activeSort, setActiveSort] = useState("all")

  useEffect(() => {
    // Check URL for sort parameter on mount
    const urlParams = new URLSearchParams(window.location.search)
    const sortParam = urlParams.get("sort")
    if (sortParam && sortOptions.find((option) => option.id === sortParam)) {
      setActiveSort(sortParam)
    }
  }, [])

  const handleSortChange = (sortType: string) => {
    setActiveSort(sortType)

    // Update URL with sort parameter
    const url = new URL(window.location.href)
    url.searchParams.set("sort", sortType)
    window.history.pushState({}, "", url.toString())

    // Trigger post refetch with new sort
    console.log(`Sorting by: ${sortType}`)

    // Call the callback if provided
    if (onSortChange) {
      onSortChange(sortType)
    }

    // Trigger a custom event for other components to listen to
    window.dispatchEvent(new CustomEvent("sortChange", { detail: { sortType } }))
  }

  return (
    <Card className="p-2 bg-white/80 backdrop-blur-sm shadow-lg border-0">
      <div className="flex items-center space-x-2 overflow-x-auto">
        {sortOptions.map((option) => {
          const Icon = option.icon
          return (
            <Button
              key={option.id}
              variant={activeSort === option.id ? "default" : "ghost"}
              size="sm"
              onClick={() => handleSortChange(option.id)}
              className={`flex items-center space-x-2 whitespace-nowrap transition-all ${
                activeSort === option.id
                  ? "bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg"
                  : "hover:bg-orange-50 hover:text-orange-600"
              }`}
              title={option.description}
            >
              <Icon className="w-4 h-4" />
              <span>{option.label}</span>
            </Button>
          )
        })}
      </div>
    </Card>
  )
}
