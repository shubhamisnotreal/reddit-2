"use client"

import { useState, useEffect } from "react"
import { PostCard } from "./post-card"

// Extended posts data with more variety from different communities
const allCommunityPosts = [
  {
    id: "react-1",
    title: "📱 First look at my new mobile app design - thoughts?",
    content:
      "I've been working on this fitness tracking app design for the past week. It's my first attempt at mobile UI/UX. I'd love to get some feedback from the community before I start development. What do you think about the color scheme and layout?",
    author: "design_newbie",
    subreddit: "design",
    votes: 23,
    comments: 8,
    timeAgo: "15 minutes ago",
    awards: [],
    image: "/images/mobile-app-mockup.png",
    flair: "Feedback",
    views: 156,
    sortScore: { hot: 25, new: 100, top: 15, rising: 30, controversial: 10 },
    createdAt: new Date(Date.now() - 15 * 60 * 1000),
  },
  {
    id: "gamedev-1",
    title: "🎮 Just finished my first game in Unity - a simple platformer",
    content:
      "After following tutorials for months, I finally completed my first game! It's a basic 2D platformer with 5 levels. The graphics are simple but I'm proud of the mechanics I implemented. Planning to add more levels and maybe publish it. Any Unity developers here with advice?",
    author: "indie_dev_2024",
    subreddit: "gamedev",
    votes: 67,
    comments: 12,
    timeAgo: "45 minutes ago",
    awards: [{ type: "wholesome", count: 2, icon: "🤗" }],
    image: "/images/unity-platformer.png",
    flair: "First Game",
    views: 289,
    sortScore: { hot: 35, new: 95, top: 25, rising: 45, controversial: 5 },
    createdAt: new Date(Date.now() - 45 * 60 * 1000),
  },
  {
    id: "webdev-1",
    title: "🏆 I recreated the entire Reddit homepage using only CSS Grid and Flexbox",
    content:
      "Challenge accepted! Someone on Twitter said it was impossible to recreate Reddit's complex layout using only CSS Grid and Flexbox (no JavaScript for layout). Took me 3 days, but here's the result. Fully responsive, pixel-perfect, and the code is surprisingly clean. Source code in comments!",
    author: "css_wizard",
    subreddit: "webdev",
    votes: 8934,
    comments: 456,
    timeAgo: "1 day ago",
    awards: [
      { type: "gold", count: 15, icon: "🥇" },
      { type: "genius", count: 8, icon: "🧠" },
      { type: "helpful", count: 32, icon: "🙋" },
    ],
    image: "/images/css-grid-layout.png",
    flair: "CSS Magic",
    views: 45230,
    sortScore: { hot: 75, new: 40, top: 100, rising: 20, controversial: 25 },
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
  },
  {
    id: "programming-1",
    title: "🚀 Just launched my React app and it got featured on Product Hunt!",
    content:
      "After 6 months of development, my side project just hit #1 on Product Hunt! The response has been incredible - 2000+ upvotes, 500+ comments, and 50+ new users in the first hour. This community has been so supportive throughout my journey. Thank you all!",
    author: "startup_founder",
    subreddit: "reactjs",
    votes: 2847,
    comments: 234,
    timeAgo: "3 hours ago",
    awards: [
      { type: "rocket", count: 12, icon: "🚀" },
      { type: "helpful", count: 8, icon: "🙋" },
      { type: "gold", count: 3, icon: "🥇" },
    ],
    image: "/images/react-app-dashboard.png",
    flair: "Success Story",
    views: 15420,
    sortScore: { hot: 95, new: 70, top: 85, rising: 90, controversial: 20 },
    createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
  },
  {
    id: "security-1",
    title: "🔥 Breaking: Major security vulnerability found in popular npm package",
    content:
      "URGENT: A critical security flaw has been discovered in the 'popular-utils' npm package (50M+ weekly downloads). The vulnerability allows remote code execution. Update to version 2.1.4 immediately. CVE-2024-1234 has been assigned.",
    author: "security_researcher",
    subreddit: "programming",
    votes: 4521,
    comments: 387,
    timeAgo: "2 hours ago",
    awards: [
      { type: "helpful", count: 25, icon: "🙋" },
      { type: "important", count: 15, icon: "⚠️" },
    ],
    image: "/images/security-vulnerability.png",
    flair: "Security Alert",
    isPinned: true,
    views: 28750,
    sortScore: { hot: 98, new: 80, top: 95, rising: 85, controversial: 15 },
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
  },
  {
    id: "javascript-1",
    title: "🔥 Unpopular Opinion: TypeScript is overrated and adds unnecessary complexity",
    content:
      "I know this will be controversial, but after 3 years of TypeScript, I'm going back to JavaScript. The type system is great in theory, but in practice, it slows down development, creates analysis paralysis, and the benefits don't outweigh the costs for most projects. Change my mind.",
    author: "js_purist",
    subreddit: "javascript",
    votes: 2156,
    comments: 534,
    timeAgo: "6 hours ago",
    awards: [
      { type: "controversial", count: 15, icon: "⚡" },
      { type: "brave", count: 8, icon: "🦁" },
    ],
    flair: "Unpopular Opinion",
    views: 12340,
    sortScore: { hot: 70, new: 50, top: 65, rising: 40, controversial: 95 },
    createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
  },
  {
    id: "learnprogramming-1",
    title: "📚 Free coding bootcamp alternative: I created a 12-week curriculum",
    content:
      "Coding bootcamps cost $15k+. I created a free alternative: 12-week full-stack curriculum with projects, code reviews, and mentorship. 500+ students have completed it with 80% job placement rate. Everything is open source and community-driven.",
    author: "education_advocate",
    subreddit: "learnprogramming",
    votes: 3456,
    comments: 234,
    timeAgo: "4 hours ago",
    awards: [
      { type: "helpful", count: 45, icon: "🙋" },
      { type: "heart", count: 23, icon: "❤️" },
    ],
    image: "/images/coding-bootcamp.png",
    flair: "Education",
    views: 18920,
    sortScore: { hot: 88, new: 60, top: 75, rising: 70, controversial: 25 },
    createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
  },
]

interface PostFeedProps {
  sortBy?: string
  posts?: any[]
  showUserPosts?: boolean
  currentUser?: string
}

export function PostFeed({
  sortBy = "all",
  posts = allCommunityPosts,
  showUserPosts = false,
  currentUser,
}: PostFeedProps) {
  const [sortedPosts, setSortedPosts] = useState(posts)

  useEffect(() => {
    let postsToSort = [...posts]

    // Filter for user posts if requested
    if (showUserPosts && currentUser) {
      postsToSort = postsToSort.filter((post) => post.author === currentUser)
    }

    switch (sortBy) {
      case "all":
        // Show all posts from all communities, sorted by a mix of hot and new
        postsToSort.sort((a, b) => {
          const aScore = a.sortScore.hot * 0.6 + a.sortScore.new * 0.4
          const bScore = b.sortScore.hot * 0.6 + b.sortScore.new * 0.4
          return bScore - aScore
        })
        break
      case "best":
        postsToSort.sort((a, b) => {
          // Best algorithm: combination of votes and engagement
          const aScore = a.votes * 0.7 + a.comments * 0.3
          const bScore = b.votes * 0.7 + b.comments * 0.3
          return bScore - aScore
        })
        break
      case "hot":
        postsToSort.sort((a, b) => b.sortScore.hot - a.sortScore.hot)
        break
      case "new":
        postsToSort.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        break
      case "top":
        postsToSort.sort((a, b) => b.votes - a.votes)
        break
      case "rising":
        postsToSort.sort((a, b) => b.sortScore.rising - a.sortScore.rising)
        break
      case "controversial":
        postsToSort.sort((a, b) => b.sortScore.controversial - a.sortScore.controversial)
        break
      default:
        postsToSort.sort((a, b) => {
          const aScore = a.sortScore.hot * 0.6 + a.sortScore.new * 0.4
          const bScore = b.sortScore.hot * 0.6 + b.sortScore.new * 0.4
          return bScore - aScore
        })
    }

    setSortedPosts(postsToSort)
  }, [sortBy, posts, showUserPosts, currentUser])

  return (
    <div className="space-y-6">
      {sortedPosts.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-gray-500 text-lg mb-2">{showUserPosts ? "No posts yet" : "No posts found"}</div>
          <div className="text-gray-400 text-sm">
            {showUserPosts ? "Create your first post to see it here!" : "Be the first to create a post!"}
          </div>
        </div>
      ) : (
        sortedPosts.map((post) => <PostCard key={post.id} post={post} />)
      )}
    </div>
  )
}
