"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Info, Crown, Users, Star, Shield, Clock } from "lucide-react"
import { useState } from "react"

export function Sidebar() {
  const [joinedCommunities, setJoinedCommunities] = useState<string[]>(["reactjs"])

  const handleJoinCommunity = (communityName: string) => {
    if (joinedCommunities.includes(communityName)) {
      setJoinedCommunities((prev) => prev.filter((name) => name !== communityName))
      console.log(`Left r/${communityName}`)
    } else {
      setJoinedCommunities((prev) => [...prev, communityName])
      console.log(`Joined r/${communityName}`)
    }
  }

  const handlePremiumClick = () => {
    // Navigate to premium page or open premium modal
    window.location.href = "/premium"
  }

  return (
    <div className="space-y-6">
      {/* Popular Communities */}
      <Card className="bg-gradient-to-br from-white to-blue-50 shadow-xl border-0 overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-blue-200 to-purple-200 rounded-full -translate-y-12 translate-x-12 opacity-20"></div>
        <CardHeader className="pb-3 relative">
          <CardTitle className="text-lg flex items-center space-x-2">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Growing Communities
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 relative">
          {[
            { name: "reactjs", members: "2.1K", icon: "⚛️", growth: "+12%", verified: true },
            { name: "javascript", members: "3.2K", icon: "🟨", growth: "+8%", verified: true },
            { name: "webdev", members: "1.8K", icon: "💻", growth: "+15%", verified: false },
            { name: "programming", members: "4.5K", icon: "👨‍💻", growth: "+5%", verified: true },
            { name: "node", members: "890", icon: "🟢", growth: "+20%", verified: false },
          ].map((community) => (
            <div
              key={community.name}
              className="flex items-center justify-between p-3 rounded-xl hover:bg-white/60 transition-all group"
            >
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-gray-100 to-gray-200 flex items-center justify-center text-lg shadow-md">
                    {community.icon}
                  </div>
                  {community.verified && (
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                      <Shield className="w-2 h-2 text-white" />
                    </div>
                  )}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <p className="font-semibold text-sm group-hover:text-blue-600 transition-colors">
                      r/{community.name}
                    </p>
                    <Badge variant="outline" className="text-xs text-green-600 border-green-300 bg-green-50">
                      {community.growth}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-500 flex items-center space-x-1">
                    <Users className="w-3 h-3" />
                    <span>{community.members} members</span>
                  </p>
                </div>
              </div>
              <Button
                size="sm"
                onClick={() => handleJoinCommunity(community.name)}
                className={
                  joinedCommunities.includes(community.name)
                    ? "bg-gray-200 text-gray-700 hover:bg-gray-300"
                    : "bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white shadow-md"
                }
              >
                {joinedCommunities.includes(community.name) ? "Joined" : "Join"}
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Reddit Premium */}
      <Card className="bg-gradient-to-br from-yellow-50 via-orange-50 to-red-50 border-0 shadow-xl overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-yellow-200 to-orange-200 rounded-full -translate-y-16 translate-x-16 opacity-30"></div>
        <CardContent className="p-6 relative">
          <div className="flex items-center space-x-4 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
              <Crown className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
                Reddit Premium
              </h3>
              <p className="text-sm text-orange-700">Support our growing platform</p>
            </div>
          </div>

          <div className="space-y-2 mb-4">
            {["Ad-free browsing", "Exclusive awards", "Premium communities", "Monthly coins"].map((feature, index) => (
              <div key={index} className="flex items-center space-x-2 text-sm text-orange-700">
                <Star className="w-3 h-3 text-yellow-500" />
                <span>{feature}</span>
              </div>
            ))}
          </div>

          <Button
            onClick={handlePremiumClick}
            className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white shadow-lg hover:shadow-xl transition-all"
          >
            <Crown className="w-4 h-4 mr-2" />
            Try Premium
          </Button>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card className="bg-gradient-to-br from-white to-green-50 shadow-xl border-0 overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-green-200 to-emerald-200 rounded-full -translate-y-12 translate-x-12 opacity-20"></div>
        <CardHeader className="pb-3 relative">
          <CardTitle className="text-lg flex items-center space-x-2">
            <div className="p-2 bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg">
              <Clock className="w-5 h-5 text-white" />
            </div>
            <span className="bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Recent Activity
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 relative">
          <div className="space-y-3">
            {[
              { action: "Commented on", target: "Best React practices", type: "comment", time: "2h ago" },
              { action: "Upvoted 3 posts in", target: "r/javascript", type: "vote", time: "4h ago" },
              { action: "Joined", target: "r/webdev", type: "join", time: "1d ago" },
              { action: "Awarded", target: "Amazing tutorial", type: "award", time: "2d ago" },
            ].map((activity, index) => (
              <div key={index} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-white/60 transition-all">
                <div
                  className={`w-2 h-2 rounded-full ${
                    activity.type === "comment"
                      ? "bg-blue-500"
                      : activity.type === "vote"
                        ? "bg-orange-500"
                        : activity.type === "join"
                          ? "bg-green-500"
                          : "bg-yellow-500"
                  }`}
                ></div>
                <div className="flex-1">
                  <span className="text-sm text-gray-700">
                    {activity.action} <span className="font-medium text-gray-900">"{activity.target}"</span>
                  </span>
                  <div className="text-xs text-gray-500">{activity.time}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* About Platform */}
      <Card className="bg-gradient-to-br from-white to-purple-50 shadow-xl border-0 overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-purple-200 to-pink-200 rounded-full -translate-y-12 translate-x-12 opacity-20"></div>
        <CardContent className="p-6 text-center relative">
          <div className="w-12 h-12 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-lg">
            <Info className="w-6 h-6 text-white" />
          </div>
          <h3 className="font-bold text-lg mb-2 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Welcome to Reddit
          </h3>
          <p className="text-sm text-gray-600 mb-4 leading-relaxed">
            Join our growing community of developers, creators, and curious minds. Share your knowledge and discover
            amazing content.
          </p>
          <Button
            variant="outline"
            size="sm"
            className="w-full border-purple-200 text-purple-600 hover:bg-purple-50 hover:border-purple-300 transition-all"
          >
            Learn More
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
