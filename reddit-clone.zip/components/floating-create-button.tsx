"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Plus, X, FileText, ImageIcon, LinkIcon, BarChart3 } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { FileUpload } from "@/components/file-upload"

interface FloatingCreateButtonProps {
  onPostCreate?: (postData: any) => void
}

export function FloatingCreateButton({ onPostCreate }: FloatingCreateButtonProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [postType, setPostType] = useState<"text" | "image" | "link" | "poll">("text")
  const [formData, setFormData] = useState({
    subreddit: "",
    title: "",
    content: "",
    url: "",
    nsfw: false,
    spoiler: false,
    uploadedFiles: [] as any[],
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const quickActions = [
    { type: "text", icon: FileText, label: "Text Post", color: "from-blue-500 to-blue-600" },
    { type: "image", icon: ImageIcon, label: "Image", color: "from-green-500 to-green-600" },
    { type: "link", icon: LinkIcon, label: "Link", color: "from-purple-500 to-purple-600" },
    { type: "poll", icon: BarChart3, label: "Poll", color: "from-yellow-500 to-yellow-600" },
  ]

  const handleQuickAction = (type: string) => {
    setPostType(type as any)
    setIsDialogOpen(true)
    setIsExpanded(false)
  }

  const handleSubmit = async () => {
    if (!formData.title.trim() || !formData.subreddit) {
      alert("Please fill in required fields")
      return
    }

    setIsSubmitting(true)

    const postData = {
      title: formData.title,
      content: formData.content,
      subreddit: formData.subreddit,
      url: formData.url,
      nsfw: formData.nsfw,
      spoiler: formData.spoiler,
      postType: postType,
      image: postType === "image" ? "/placeholder.svg?height=400&width=600" : undefined,
      flair: "General",
    }

    // Simulate API call
    setTimeout(() => {
      if (onPostCreate) {
        onPostCreate(postData)
      }

      console.log("Post created:", postData)
      alert("Post created successfully!")
      setIsSubmitting(false)
      setIsDialogOpen(false)

      // Reset form
      setFormData({
        subreddit: "",
        title: "",
        content: "",
        url: "",
        nsfw: false,
        spoiler: false,
        uploadedFiles: [] as any[],
      })
    }, 1000)
  }

  return (
    <>
      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end space-y-3">
        {/* Quick Action Buttons */}
        {isExpanded && (
          <div className="flex flex-col space-y-2 animate-in slide-in-from-bottom-2 duration-200">
            {quickActions.map((action) => {
              const Icon = action.icon
              return (
                <Button
                  key={action.type}
                  onClick={() => handleQuickAction(action.type)}
                  className={`w-14 h-14 rounded-full shadow-lg bg-gradient-to-r ${action.color} hover:scale-110 transition-all duration-200`}
                  title={action.label}
                >
                  <Icon className="w-6 h-6 text-white" />
                </Button>
              )
            })}
          </div>
        )}

        {/* Main Create Button */}
        <Button
          onClick={() => setIsExpanded(!isExpanded)}
          className={`w-16 h-16 rounded-full shadow-2xl bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 hover:scale-110 transition-all duration-300 ${
            isExpanded ? "rotate-45" : ""
          }`}
        >
          {isExpanded ? <X className="w-7 h-7 text-white" /> : <Plus className="w-7 h-7 text-white" />}
        </Button>
      </div>

      {/* Create Post Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
              Create a {postType} post
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <div>
              <Label htmlFor="subreddit" className="text-sm font-medium">
                Choose a community
              </Label>
              <Select
                value={formData.subreddit}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, subreddit: value }))}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select a subreddit" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="reactjs">
                    <div className="flex items-center space-x-2">
                      <span>⚛️</span>
                      <span>r/reactjs</span>
                      <Badge variant="secondary" className="ml-2">
                        2.1M
                      </Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="javascript">
                    <div className="flex items-center space-x-2">
                      <span>🟨</span>
                      <span>r/javascript</span>
                      <Badge variant="secondary" className="ml-2">
                        3.2M
                      </Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="webdev">
                    <div className="flex items-center space-x-2">
                      <span>💻</span>
                      <span>r/webdev</span>
                      <Badge variant="secondary" className="ml-2">
                        1.8M
                      </Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="programming">
                    <div className="flex items-center space-x-2">
                      <span>👨‍💻</span>
                      <span>r/programming</span>
                      <Badge variant="secondary" className="ml-2">
                        4.5M
                      </Badge>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="title" className="text-sm font-medium">
                Title
              </Label>
              <Input
                id="title"
                placeholder="An interesting title"
                value={formData.title}
                onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
                className="mt-2 focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
              />
            </div>

            {postType === "text" && (
              <div>
                <Label htmlFor="content" className="text-sm font-medium">
                  Text (optional)
                </Label>
                <Textarea
                  id="content"
                  placeholder="What are your thoughts?"
                  value={formData.content}
                  onChange={(e) => setFormData((prev) => ({ ...prev, content: e.target.value }))}
                  className="min-h-32 mt-2 focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
                />
              </div>
            )}

            {postType === "image" && (
              <div>
                <Label htmlFor="image" className="text-sm font-medium">
                  Upload Images, Videos, or GIFs
                </Label>
                <FileUpload
                  onFilesChange={(files) => {
                    setFormData((prev) => ({ ...prev, uploadedFiles: files }))
                  }}
                  maxFiles={3}
                  maxSize={25}
                  acceptedTypes={["image/*", "video/*", ".gif"]}
                  allowFolders={false}
                />
              </div>
            )}

            {postType === "link" && (
              <div>
                <Label htmlFor="url" className="text-sm font-medium">
                  URL
                </Label>
                <Input
                  id="url"
                  placeholder="https://example.com"
                  value={formData.url}
                  onChange={(e) => setFormData((prev) => ({ ...prev, url: e.target.value }))}
                  className="mt-2 focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
                />
              </div>
            )}

            {postType === "poll" && (
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium">Poll Options</Label>
                  <div className="space-y-2 mt-2">
                    <Input
                      placeholder="Option 1"
                      className="focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
                    />
                    <Input
                      placeholder="Option 2"
                      className="focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
                    />
                    <Button variant="outline" size="sm" className="w-full">
                      Add Option
                    </Button>
                  </div>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t">
              <div className="flex items-center space-x-4">
                <Label className="text-sm font-medium">Post Settings</Label>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="nsfw"
                    checked={formData.nsfw}
                    onChange={(e) => setFormData((prev) => ({ ...prev, nsfw: e.target.checked }))}
                    className="rounded"
                  />
                  <Label htmlFor="nsfw" className="text-sm">
                    NSFW
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="spoiler"
                    checked={formData.spoiler}
                    onChange={(e) => setFormData((prev) => ({ ...prev, spoiler: e.target.checked }))}
                    className="rounded"
                  />
                  <Label htmlFor="spoiler" className="text-sm">
                    Spoiler
                  </Label>
                </div>
              </div>
              <div className="flex space-x-3">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting || !formData.title.trim() || !formData.subreddit}
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 shadow-lg"
                >
                  {isSubmitting ? "Posting..." : "Post"}
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
