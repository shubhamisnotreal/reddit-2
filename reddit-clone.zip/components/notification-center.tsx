"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Bell, MessageSquare, ArrowUp, Award, Users, X } from "lucide-react"

interface Notification {
  id: string
  type: "upvote" | "comment" | "award" | "follow" | "mention"
  title: string
  content: string
  timestamp: string
  read: boolean
  actionUrl?: string
}

export function NotificationCenter() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      type: "upvote",
      title: "Your post got 100 upvotes!",
      content: "Just finished building my first React app!",
      timestamp: "2 hours ago",
      read: false,
      actionUrl: "/post/1",
    },
    {
      id: "2",
      type: "comment",
      title: "New comment on your post",
      content: 'tech_enthusiast replied: "This is exactly what I needed!"',
      timestamp: "4 hours ago",
      read: false,
      actionUrl: "/post/1#comment-2",
    },
    {
      id: "3",
      type: "award",
      title: "You received a Gold award!",
      content: "Someone gave your comment a Gold award",
      timestamp: "1 day ago",
      read: true,
      actionUrl: "/post/2#comment-5",
    },
    {
      id: "4",
      type: "follow",
      title: "New follower",
      content: "code_master started following you",
      timestamp: "2 days ago",
      read: true,
      actionUrl: "/u/code_master",
    },
  ])

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
  }

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id))
  }

  const getIcon = (type: string) => {
    switch (type) {
      case "upvote":
        return <ArrowUp className="w-4 h-4 text-orange-500" />
      case "comment":
        return <MessageSquare className="w-4 h-4 text-blue-500" />
      case "award":
        return <Award className="w-4 h-4 text-yellow-500" />
      case "follow":
        return <Users className="w-4 h-4 text-green-500" />
      default:
        return <Bell className="w-4 h-4 text-gray-500" />
    }
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="relative hover:bg-orange-50 transition-all">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center text-xs bg-gradient-to-r from-blue-500 to-purple-500 animate-pulse">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle>Notifications</DialogTitle>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllAsRead}>
              Mark all read
            </Button>
          )}
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-2">
          {notifications.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Bell className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No notifications yet</p>
            </div>
          ) : (
            notifications.map((notification) => (
              <div
                key={notification.id}
                className={`p-3 rounded-lg border transition-all hover:shadow-md cursor-pointer ${
                  notification.read ? "bg-gray-50" : "bg-blue-50 border-blue-200"
                }`}
                onClick={() => {
                  markAsRead(notification.id)
                  if (notification.actionUrl) {
                    window.location.href = notification.actionUrl
                  }
                }}
              >
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">{getIcon(notification.type)}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">{notification.title}</p>
                    <p className="text-sm text-gray-600 truncate">{notification.content}</p>
                    <p className="text-xs text-gray-500 mt-1">{notification.timestamp}</p>
                  </div>
                  <div className="flex items-center space-x-1">
                    {!notification.read && <div className="w-2 h-2 bg-blue-500 rounded-full"></div>}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-6 h-6 opacity-0 group-hover:opacity-100"
                      onClick={(e) => {
                        e.stopPropagation()
                        deleteNotification(notification.id)
                      }}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
