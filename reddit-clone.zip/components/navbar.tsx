"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Search, Plus, User, Menu, Home, Settings, Gift, Crown, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { NotificationCenter } from "./notification-center"
import { MessageCenter } from "./message-center"

export function Navbar() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [mounted, setMounted] = useState(false)

  // Handle hydration
  useEffect(() => {
    setMounted(true)
  }, [])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      // Navigate to search results
      window.location.href = `/search?q=${encodeURIComponent(searchQuery)}`
      setIsSearchOpen(false)
      setSearchQuery("")
    }
  }

  const handleSearchClick = () => {
    setIsSearchOpen(true)
  }

  const handleHomeClick = () => {
    window.location.href = "/"
  }

  const handlePremiumClick = () => {
    window.location.href = "/premium"
  }

  const handleCreateClick = () => {
    // Try to trigger the create post modal via global function
    if ((window as any).triggerCreatePost) {
      ;(window as any).triggerCreatePost()
    } else {
      // Fallback: try to find and click the create post input
      const createPostInput = document.querySelector("[data-create-post-trigger]") as HTMLElement
      if (createPostInput) {
        createPostInput.click()
      } else {
        // Final fallback: navigate to submit page
        window.location.href = "/submit"
      }
    }
  }

  const handleProfileClick = () => {
    window.location.href = "/u/john_doe"
  }

  const handleSettingsClick = () => {
    window.location.href = "/settings"
  }

  const handleAvatarClick = () => {
    window.location.href = "/avatar"
  }

  const handleModToolsClick = () => {
    window.location.href = "/mod"
  }

  const handleSignOut = () => {
    // Clear user session and redirect to login
    localStorage.removeItem("user_session")
    sessionStorage.clear()
    window.location.href = "/login"
  }

  if (!mounted) {
    return null // Prevent hydration mismatch
  }

  return (
    <>
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-gray-200/50 shadow-lg transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo and Navigation */}
            <div className="flex items-center space-x-6">
              <Link href="/" className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center shadow-lg">
                  <span className="text-white font-bold text-lg">R</span>
                </div>
                <span className="font-bold text-2xl bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent hidden sm:block">
                  Reddit
                </span>
              </Link>

              <div className="hidden md:flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleHomeClick}
                  className="flex items-center space-x-2 hover:bg-orange-50 hover:text-orange-600 transition-all"
                >
                  <Home className="w-4 h-4" />
                  <span>Home</span>
                </Button>
              </div>
            </div>

            {/* Right Side Actions */}
            <div className="flex items-center space-x-3">
              {/* Premium Badge */}
              <Button
                variant="ghost"
                size="sm"
                onClick={handlePremiumClick}
                className="hidden lg:flex items-center space-x-2 text-yellow-600 hover:bg-yellow-50 transition-all"
              >
                <Crown className="w-4 h-4" />
                <span>Premium</span>
              </Button>

              {/* Messages with notification badge */}
              <MessageCenter />

              {/* Notifications with notification badge */}
              <NotificationCenter />

              {/* Search Button */}
              <Button
                onClick={handleSearchClick}
                className="flex items-center space-x-2 bg-gray-100 hover:bg-gray-200 text-gray-700 border border-gray-300 shadow-sm hover:shadow-md transition-all"
              >
                <Search className="w-4 h-4" />
                <span className="hidden sm:inline">Search</span>
              </Button>

              {/* Create Post Button */}
              <Button
                onClick={handleCreateClick}
                className="hidden sm:flex items-center space-x-2 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 shadow-lg hover:shadow-xl transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Create</span>
              </Button>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2 hover:bg-orange-50 transition-all">
                    <Avatar className="w-8 h-8 ring-2 ring-orange-200">
                      <AvatarImage src="/placeholder-user.jpg" />
                      <AvatarFallback className="bg-gradient-to-r from-orange-500 to-red-500 text-white">
                        JD
                      </AvatarFallback>
                    </Avatar>
                    <div className="hidden sm:block text-left">
                      <div className="text-sm font-medium">john_doe</div>
                      <div className="text-xs text-gray-500 flex items-center">
                        <span>247 karma</span>
                        <Crown className="w-3 h-3 ml-1 text-yellow-500" />
                      </div>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-64 p-2 bg-white border-gray-200">
                  <div className="p-3 border-b border-gray-200">
                    <div className="font-medium">john_doe</div>
                    <div className="text-sm text-gray-500">u/john_doe • 247 karma</div>
                  </div>
                  <DropdownMenuItem onClick={handleProfileClick} className="flex items-center space-x-2">
                    <User className="w-4 h-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleAvatarClick} className="flex items-center space-x-2">
                    <Gift className="w-4 h-4" />
                    <span>Avatar</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleSettingsClick} className="flex items-center space-x-2">
                    <Settings className="w-4 h-4" />
                    <span>User Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handlePremiumClick} className="flex items-center space-x-2">
                    <Crown className="w-4 h-4 text-yellow-500" />
                    <span>Premium</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleModToolsClick} className="flex items-center space-x-2">
                    <Shield className="w-4 h-4" />
                    <span>Mod Tools</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="text-red-600">
                    Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Search Dialog */}
      <Dialog open={isSearchOpen} onOpenChange={setIsSearchOpen}>
        <DialogContent className="max-w-2xl bg-white border-gray-200">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Search className="w-5 h-5 text-orange-500" />
              <span>Search Reddit</span>
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSearch} className="space-y-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                type="text"
                placeholder="Search for posts, communities, and users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 pr-4 py-4 text-lg bg-gray-50 border-gray-200 focus:bg-white focus:border-orange-500 focus:ring-2 focus:ring-orange-200 rounded-xl"
                autoFocus
              />
            </div>

            <div className="flex justify-end space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsSearchOpen(false)}
                className="border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={!searchQuery.trim()}
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
              >
                Search
              </Button>
            </div>

            {/* Quick Search Suggestions */}
            <div className="border-t border-gray-200 pt-4">
              <h4 className="text-sm font-medium text-gray-700 mb-3">Popular searches</h4>
              <div className="flex flex-wrap gap-2">
                {["React", "JavaScript", "Web Development", "Programming", "AI", "Tech News"].map((term) => (
                  <Button
                    key={term}
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSearchQuery(term)
                      handleSearch(new Event("submit") as any)
                    }}
                    className="text-xs hover:bg-orange-50 hover:border-orange-300 border-gray-300 text-gray-700"
                  >
                    {term}
                  </Button>
                ))}
              </div>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  )
}
