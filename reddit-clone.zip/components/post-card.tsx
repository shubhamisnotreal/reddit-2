"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowUp,
  ArrowDown,
  MessageSquare,
  Share,
  Bookmark,
  MoreHorizontal,
  Award,
  Eye,
  Clock,
  Pin,
  Shield,
  Flag,
  Copy,
  ExternalLink,
  Check,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { AwardDialog } from "./award-dialog"

interface PostCardProps {
  post: {
    id: string
    title: string
    content: string
    author: string
    subreddit: string
    votes: number
    comments: number
    timeAgo: string
    awards: Array<{ type: string; count: number; icon: string }>
    image?: string
    flair?: string
    isPinned?: boolean
    isLocked?: boolean
    views?: number
    crosspostFrom?: string
  }
}

export function PostCard({ post }: PostCardProps) {
  const [userVote, setUserVote] = useState<"up" | "down" | null>(null)
  const [currentVotes, setCurrentVotes] = useState(post.votes)
  const [isBookmarked, setIsBookmarked] = useState(false)
  const [isHidden, setIsHidden] = useState(false)
  const [currentComments, setCurrentComments] = useState(post.comments)
  const [hasAwarded, setHasAwarded] = useState(false)
  const [shareCount, setShareCount] = useState(0)

  // Simple toast function
  const showToast = (message: string) => {
    // Create a simple toast notification
    const toast = document.createElement("div")
    toast.className =
      "fixed top-4 right-4 bg-black text-white px-4 py-2 rounded-lg shadow-lg z-50 transition-all duration-300"
    toast.textContent = message
    document.body.appendChild(toast)

    // Animate in
    setTimeout(() => {
      toast.style.transform = "translateX(0)"
      toast.style.opacity = "1"
    }, 100)

    // Remove after 2 seconds
    setTimeout(() => {
      toast.style.transform = "translateX(100%)"
      toast.style.opacity = "0"
      setTimeout(() => {
        document.body.removeChild(toast)
      }, 300)
    }, 2000)
  }

  const handleVote = (type: "up" | "down") => {
    if (userVote === type) {
      // Remove vote
      setUserVote(null)
      setCurrentVotes(post.votes)
      showToast("Vote removed")
    } else {
      const previousVote = userVote
      setUserVote(type)

      let newVotes = post.votes
      if (previousVote === "up") newVotes -= 1
      if (previousVote === "down") newVotes += 1
      if (type === "up") newVotes += 1
      if (type === "down") newVotes -= 1

      setCurrentVotes(newVotes)
      showToast(type === "up" ? "Upvoted!" : "Downvoted!")
    }
  }

  const handleComments = () => {
    // Navigate to post detail page
    window.location.href = `/post/${post.id}`
  }

  const handleAward = () => {
    setHasAwarded(true)
    showToast("Award given! 🏆")
  }

  const handleShare = async () => {
    const postUrl = `${window.location.origin}/post/${post.id}`

    if (navigator.share) {
      try {
        await navigator.share({
          title: post.title,
          text: post.content.substring(0, 100) + "...",
          url: postUrl,
        })
        setShareCount((prev) => prev + 1)
        showToast("Post shared successfully!")
      } catch (error) {
        // User cancelled sharing
      }
    } else {
      // Fallback to clipboard
      try {
        await navigator.clipboard.writeText(postUrl)
        setShareCount((prev) => prev + 1)
        showToast("Link copied to clipboard!")
      } catch (error) {
        showToast("Failed to copy link")
      }
    }
  }

  const handleSave = () => {
    setIsBookmarked(!isBookmarked)

    // Save to localStorage
    const savedPosts = JSON.parse(localStorage.getItem("savedPosts") || "[]")
    if (!isBookmarked) {
      savedPosts.push(post.id)
      localStorage.setItem("savedPosts", JSON.stringify(savedPosts))
      showToast("Post saved!")
    } else {
      const updatedSaved = savedPosts.filter((id: string) => id !== post.id)
      localStorage.setItem("savedPosts", JSON.stringify(updatedSaved))
      showToast("Post unsaved")
    }
  }

  const handleHide = () => {
    setIsHidden(true)
    showToast("Post hidden")
  }

  const handleReport = () => {
    showToast("Post reported. Thank you for keeping Reddit safe!")
  }

  const formatVoteCount = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}k`
    }
    return count.toString()
  }

  const formatCommentCount = (count: number) => {
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}k`
    }
    return count.toString()
  }

  const totalAwards = post.awards?.reduce((sum, award) => sum + award.count, 0) || 0

  if (isHidden) {
    return (
      <Card className="bg-gray-100 border-gray-200">
        <CardContent className="p-4 text-center">
          <p className="text-gray-500">Post hidden</p>
          <Button variant="ghost" size="sm" onClick={() => setIsHidden(false)} className="mt-2">
            Show post
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 border-0 shadow-lg hover:scale-[1.02] group">
      {post.isPinned && (
        <div className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-4 py-2 text-sm flex items-center space-x-2">
          <Pin className="w-4 h-4" />
          <span>Pinned by moderators</span>
        </div>
      )}

      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href={`/r/${post.subreddit}`} className="flex items-center space-x-2 group/subreddit">
              <Avatar className="w-7 h-7 ring-2 ring-orange-200 group-hover/subreddit:ring-orange-400 transition-all">
                <AvatarImage src={`/placeholder.svg?height=28&width=28`} />
                <AvatarFallback className="text-xs bg-gradient-to-r from-orange-500 to-red-500 text-white">
                  r/
                </AvatarFallback>
              </Avatar>
              <span className="font-semibold text-sm hover:text-orange-600 transition-colors">r/{post.subreddit}</span>
            </Link>

            {post.flair && (
              <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-200 transition-colors">
                {post.flair}
              </Badge>
            )}

            <span className="text-gray-400">•</span>
            <span className="text-sm text-gray-500">Posted by</span>
            <Link
              href={`/u/${post.author}`}
              className="text-sm text-gray-700 hover:text-orange-600 font-medium transition-colors"
            >
              u/{post.author}
            </Link>
            <span className="text-sm text-gray-500 flex items-center space-x-1">
              <Clock className="w-3 h-3" />
              <span>{post.timeAgo}</span>
            </span>

            {post.isLocked && (
              <Badge variant="outline" className="text-yellow-600 border-yellow-300">
                <Shield className="w-3 h-3 mr-1" />
                Locked
              </Badge>
            )}
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-8 h-8 opacity-0 group-hover:opacity-100 transition-all hover:bg-orange-50"
              >
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 bg-white border-gray-200">
              <DropdownMenuItem onClick={handleSave} className="flex items-center space-x-2">
                <Bookmark className={`w-4 h-4 ${isBookmarked ? "fill-current text-purple-600" : ""}`} />
                <span>{isBookmarked ? "Unsave" : "Save"}</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleHide} className="flex items-center space-x-2">
                <Eye className="w-4 h-4" />
                <span>Hide</span>
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => {
                  navigator.clipboard.writeText(`${window.location.origin}/post/${post.id}`)
                  showToast("Link copied to clipboard!")
                }}
                className="flex items-center space-x-2"
              >
                <Copy className="w-4 h-4" />
                <span>Copy link</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleReport} className="flex items-center space-x-2 text-red-600">
                <Flag className="w-4 h-4" />
                <span>Report</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Awards Display */}
        {totalAwards > 0 && post.awards && (
          <div className="flex items-center space-x-2 mt-2">
            <div className="flex items-center space-x-1">
              {post.awards.slice(0, 3).map((award, index) => (
                <div key={index} className="flex items-center space-x-1 bg-yellow-50 px-2 py-1 rounded-full">
                  <span className="text-sm">{award.icon}</span>
                  <span className="text-xs font-medium text-yellow-700">{award.count}</span>
                </div>
              ))}
              {totalAwards > 3 && (
                <Badge variant="secondary" className="text-xs">
                  +{totalAwards - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}
      </CardHeader>

      <CardContent className="pt-0">
        <Link href={`/post/${post.id}`}>
          <h2 className="text-lg font-semibold text-gray-900 hover:text-orange-600 cursor-pointer mb-3 transition-colors leading-tight">
            {post.title}
          </h2>
        </Link>

        {post.crosspostFrom && (
          <div className="mb-3 p-3 bg-gray-50 rounded-lg border-l-4 border-blue-500">
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <ExternalLink className="w-4 h-4" />
              <span>Crossposted from r/{post.crosspostFrom}</span>
            </div>
          </div>
        )}

        {post.image && (
          <div className="mb-4 group/image">
            <img
              src={post.image || "/placeholder.svg"}
              alt="Post content"
              className="w-full max-h-96 object-cover rounded-xl shadow-md group-hover/image:shadow-lg transition-all cursor-pointer"
            />
          </div>
        )}

        <p className="text-gray-700 text-sm line-clamp-3 leading-relaxed">{post.content}</p>

        {post.views && (
          <div className="flex items-center space-x-1 mt-3 text-xs text-gray-500">
            <Eye className="w-3 h-3" />
            <span>{post.views.toLocaleString()} views</span>
          </div>
        )}
      </CardContent>

      <CardFooter className="pt-0">
        <div className="flex items-center justify-between w-full">
          {/* Voting */}
          <div className="flex items-center space-x-1 bg-gray-50 rounded-full p-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleVote("up")}
              className={`rounded-full transition-all ${
                userVote === "up"
                  ? "text-orange-500 bg-orange-100 shadow-md"
                  : "text-gray-500 hover:text-orange-500 hover:bg-orange-50"
              }`}
            >
              <ArrowUp className="w-4 h-4" />
            </Button>
            <span
              className={`text-sm font-bold px-2 transition-colors ${
                userVote === "up" ? "text-orange-500" : userVote === "down" ? "text-blue-500" : "text-gray-700"
              }`}
            >
              {formatVoteCount(currentVotes)}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleVote("down")}
              className={`rounded-full transition-all ${
                userVote === "down"
                  ? "text-blue-500 bg-blue-100 shadow-md"
                  : "text-gray-500 hover:text-blue-500 hover:bg-blue-50"
              }`}
            >
              <ArrowDown className="w-4 h-4" />
            </Button>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleComments}
              className="flex items-center space-x-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-all"
            >
              <MessageSquare className="w-4 h-4" />
              <span className="text-sm font-medium">{formatCommentCount(currentComments)}</span>
            </Button>

            <AwardDialog>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleAward}
                className={`flex items-center space-x-2 rounded-full transition-all ${
                  hasAwarded ? "text-yellow-600 bg-yellow-50" : "text-gray-500 hover:text-yellow-600 hover:bg-yellow-50"
                }`}
              >
                <Award className="w-4 h-4" />
                <span className="text-sm">Award</span>
                {hasAwarded && <Check className="w-3 h-3" />}
              </Button>
            </AwardDialog>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleShare}
              className="flex items-center space-x-2 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-full transition-all"
            >
              <Share className="w-4 h-4" />
              <span className="text-sm">Share</span>
              {shareCount > 0 && <span className="text-xs">({shareCount})</span>}
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleSave}
              className={`rounded-full transition-all ${
                isBookmarked ? "text-purple-600 bg-purple-50" : "text-gray-500 hover:text-purple-600 hover:bg-purple-50"
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? "fill-current" : ""}`} />
            </Button>
          </div>
        </div>
      </CardFooter>
    </Card>
  )
}
