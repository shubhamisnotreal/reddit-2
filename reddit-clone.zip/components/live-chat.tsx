"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Send, Users, Settings, Smile } from "lucide-react"

interface ChatMessage {
  id: string
  user: string
  message: string
  timestamp: Date
  color: string
}

export function LiveChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      user: "tech_guru",
      message: "Anyone else excited about the new React features?",
      timestamp: new Date(Date.now() - 300000),
      color: "text-blue-600",
    },
    {
      id: "2",
      user: "code_ninja",
      message: "Yes! The new concurrent features are game-changing",
      timestamp: new Date(Date.now() - 240000),
      color: "text-green-600",
    },
    {
      id: "3",
      user: "dev_enthusiast",
      message: "I'm still learning the basics, but this community is so helpful!",
      timestamp: new Date(Date.now() - 180000),
      color: "text-purple-600",
    },
  ])

  const [newMessage, setNewMessage] = useState("")
  const [isConnected, setIsConnected] = useState(true)
  const [onlineUsers] = useState(1247)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Simulate receiving messages
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        // 30% chance every 5 seconds
        const randomMessages = [
          "Great discussion everyone!",
          "Thanks for sharing that link",
          "Anyone know about the new update?",
          "This community is awesome!",
          "Just joined, hello everyone!",
        ]

        const randomUsers = ["tech_guru", "code_ninja", "dev_enthusiast", "react_master", "js_wizard"]

        const newMsg: ChatMessage = {
          id: Date.now().toString(),
          user: randomUsers[Math.floor(Math.random() * randomUsers.length)],
          message: randomMessages[Math.floor(Math.random() * randomMessages.length)],
          timestamp: new Date(),
          color: `text-${["blue", "green", "purple", "indigo", "pink"][Math.floor(Math.random() * 5)]}-600`,
        }

        setMessages((prev) => [...prev, newMsg])
      }
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message: ChatMessage = {
        id: Date.now().toString(),
        user: "john_doe",
        message: newMessage,
        timestamp: new Date(),
        color: "text-orange-600",
      }
      setMessages((prev) => [...prev, message])
      setNewMessage("")
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage()
    }
  }

  return (
    <Card className="bg-white/90 backdrop-blur-sm shadow-xl border-0 h-96 flex flex-col">
      <CardHeader className="pb-3 border-b bg-gradient-to-r from-orange-50 to-red-50">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${isConnected ? "bg-green-500 animate-pulse" : "bg-red-500"}`}></div>
            <span className="text-lg">{isConnected ? "Live Chat" : "Disconnected"}</span>
          </div>
          <div className="flex items-center space-x-3">
            <Badge variant="secondary" className="flex items-center space-x-1">
              <Users className="w-3 h-3" />
              <span>{onlineUsers.toLocaleString()}</span>
            </Badge>
            <Button variant="ghost" size="icon" className="w-8 h-8">
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>

      <CardContent className="flex-1 p-4 overflow-hidden flex flex-col">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-3 mb-4">
          {messages.map((message) => (
            <div key={message.id} className="flex items-start space-x-2">
              <Avatar className="w-6 h-6">
                <AvatarImage src="/placeholder-user.jpg" />
                <AvatarFallback className="text-xs">{message.user[0].toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2">
                  <span className={`text-sm font-medium ${message.color}`}>{message.user}</span>
                  <span className="text-xs text-gray-500">
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                </div>
                <p className="text-sm text-gray-700 break-words">{message.message}</p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="flex items-center space-x-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type a message..."
            className="flex-1 focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
          />
          <Button variant="ghost" size="icon" className="text-gray-500 hover:text-orange-600">
            <Smile className="w-4 h-4" />
          </Button>
          <Button
            onClick={handleSendMessage}
            disabled={!newMessage.trim()}
            className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
