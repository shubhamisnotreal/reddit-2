"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Coins, Gift } from "lucide-react"

const awards = [
  { id: "silver", name: "Silver", icon: "🥈", cost: 100, description: "Shows appreciation" },
  { id: "gold", name: "Gold", icon: "🥇", cost: 500, description: "Gives premium benefits" },
  { id: "platinum", name: "Platinum", icon: "💎", cost: 1800, description: "Premium + coins" },
  { id: "wholesome", name: "Wholesome", icon: "🤗", cost: 125, description: "When you love something" },
  { id: "helpful", name: "Helpful", icon: "🙋", cost: 125, description: "Thank you stranger!" },
  { id: "rocket", name: "Rocket Like", icon: "🚀", cost: 150, description: "To the moon!" },
  { id: "heart", name: "Heartwarming", icon: "❤️", cost: 200, description: "Warms the heart" },
  { id: "mind-blown", name: "Mind Blown", icon: "🤯", cost: 250, description: "Absolutely mind-blowing" },
  { id: "genius", name: "Big Brain", icon: "🧠", cost: 300, description: "Galaxy brain moment" },
]

interface AwardDialogProps {
  children: React.ReactNode
}

export function AwardDialog({ children }: AwardDialogProps) {
  const [selectedAward, setSelectedAward] = useState<string | null>(null)
  const [userCoins, setUserCoins] = useState(2500)
  const [isAwarding, setIsAwarding] = useState(false)

  const handleGiveAward = async () => {
    if (!selectedAward) return

    const award = awards.find((a) => a.id === selectedAward)
    if (!award || userCoins < award.cost) return

    setIsAwarding(true)

    // Simulate API call
    setTimeout(() => {
      setUserCoins((prev) => prev - award.cost)
      setIsAwarding(false)
      setSelectedAward(null)

      // Show success message
      alert(`Successfully gave ${award.name} award!`)

      // Close dialog
      const closeButton = document.querySelector("[data-dialog-close]") as HTMLButtonElement
      closeButton?.click()
    }, 1000)
  }

  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Gift className="w-5 h-5 text-yellow-500" />
            <span>Give Award</span>
          </DialogTitle>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Coins className="w-4 h-4" />
            <span>You have {userCoins} coins</span>
          </div>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {awards.map((award) => (
            <div
              key={award.id}
              className={`p-4 border rounded-lg cursor-pointer transition-all hover:shadow-md ${
                selectedAward === award.id ? "border-orange-500 bg-orange-50" : "border-gray-200 hover:border-gray-300"
              }`}
              onClick={() => setSelectedAward(award.id)}
            >
              <div className="flex items-center space-x-3">
                <div className="text-2xl">{award.icon}</div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium">{award.name}</h3>
                    <Badge variant="outline" className="flex items-center space-x-1">
                      <Coins className="w-3 h-3" />
                      <span>{award.cost}</span>
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{award.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {selectedAward && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Selected Award</h4>
                <p className="text-sm text-gray-600">
                  {awards.find((a) => a.id === selectedAward)?.name} -{" "}
                  {awards.find((a) => a.id === selectedAward)?.cost} coins
                </p>
              </div>
              <Button
                onClick={handleGiveAward}
                disabled={isAwarding || userCoins < (awards.find((a) => a.id === selectedAward)?.cost || 0)}
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
              >
                {isAwarding ? "Giving Award..." : "Give Award"}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
