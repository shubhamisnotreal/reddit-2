"use client"

import { useState } from "react"
import { ArrowUp, ArrowDown, MessageSquare, MoreHorizontal, Reply } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"

interface Comment {
  id: string
  author: string
  content: string
  votes: number
  timeAgo: string
  replies?: Comment[]
}

interface CommentItemProps {
  comment: Comment
  depth?: number
  onReply: (commentId: string, replyText: string) => void
}

function CommentItem({ comment, depth = 0, onReply }: CommentItemProps) {
  const [isReplying, setIsReplying] = useState(false)
  const [userVote, setUserVote] = useState<"up" | "down" | null>(null)
  const [currentVotes, setCurrentVotes] = useState(comment.votes)
  const [replyText, setReplyText] = useState("")

  const handleVote = (type: "up" | "down") => {
    if (userVote === type) {
      setUserVote(null)
      setCurrentVotes(comment.votes)
    } else {
      const previousVote = userVote
      setUserVote(type)

      let newVotes = comment.votes
      if (previousVote === "up") newVotes -= 1
      if (previousVote === "down") newVotes += 1
      if (type === "up") newVotes += 1
      if (type === "down") newVotes -= 1

      setCurrentVotes(newVotes)
    }
  }

  const handleReplySubmit = () => {
    if (replyText.trim()) {
      onReply(comment.id, replyText)
      setIsReplying(false)
      setReplyText("")
    }
  }

  return (
    <div className={`${depth > 0 ? "ml-6 border-l-2 border-gray-100 pl-4" : ""}`}>
      <div className="flex space-x-3 py-3">
        <Avatar className="w-8 h-8">
          <AvatarImage src="/placeholder-user.jpg" />
          <AvatarFallback>{comment.author[0].toUpperCase()}</AvatarFallback>
        </Avatar>

        <div className="flex-1 space-y-2">
          <div className="flex items-center space-x-2">
            <span className="font-medium text-sm">{comment.author}</span>
            <span className="text-xs text-gray-500">{comment.timeAgo}</span>
          </div>

          <p className="text-sm text-gray-700">{comment.content}</p>

          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleVote("up")}
                className={`h-6 px-2 ${userVote === "up" ? "text-orange-500 bg-orange-50" : "text-gray-500"}`}
              >
                <ArrowUp className="w-3 h-3" />
              </Button>
              <span
                className={`text-xs font-medium ${
                  userVote === "up" ? "text-orange-500" : userVote === "down" ? "text-blue-500" : "text-gray-700"
                }`}
              >
                {currentVotes}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleVote("down")}
                className={`h-6 px-2 ${userVote === "down" ? "text-blue-500 bg-blue-50" : "text-gray-500"}`}
              >
                <ArrowDown className="w-3 h-3" />
              </Button>
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsReplying(!isReplying)}
              className="h-6 px-2 text-gray-500"
            >
              <Reply className="w-3 h-3 mr-1" />
              Reply
            </Button>

            <Button variant="ghost" size="sm" className="h-6 px-2 text-gray-500">
              <MoreHorizontal className="w-3 h-3" />
            </Button>
          </div>

          {isReplying && (
            <div className="mt-3">
              <Textarea
                placeholder="What are your thoughts?"
                className="min-h-20 text-sm"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
              />
              <div className="flex justify-end space-x-2 mt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setIsReplying(false)
                    setReplyText("")
                  }}
                >
                  Cancel
                </Button>
                <Button size="sm" onClick={handleReplySubmit} disabled={!replyText.trim()}>
                  Reply
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {comment.replies &&
        comment.replies.map((reply) => (
          <CommentItem key={reply.id} comment={reply} depth={depth + 1} onReply={onReply} />
        ))}
    </div>
  )
}

export function CommentSection() {
  const [newComment, setNewComment] = useState("")
  const [comments, setComments] = useState<Comment[]>([
    {
      id: "1",
      author: "tech_enthusiast",
      content:
        "This is exactly what I needed! The explanation is clear and the examples are really helpful. Thanks for sharing!",
      votes: 42,
      timeAgo: "2 hours ago",
      replies: [
        {
          id: "2",
          author: "newbie_dev",
          content: "I agree! This helped me understand the concept much better.",
          votes: 15,
          timeAgo: "1 hour ago",
        },
      ],
    },
    {
      id: "3",
      author: "senior_dev",
      content:
        "Great post! I would also recommend checking out the official documentation for more advanced use cases. There are some edge cases that might be worth considering.",
      votes: 28,
      timeAgo: "3 hours ago",
    },
    {
      id: "4",
      author: "code_reviewer",
      content:
        "One small suggestion: you might want to add error handling for the async operations. Other than that, solid work!",
      votes: 19,
      timeAgo: "4 hours ago",
    },
  ])
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmitComment = async () => {
    if (!newComment.trim()) return

    setIsSubmitting(true)

    const comment: Comment = {
      id: Date.now().toString(),
      author: "john_doe",
      content: newComment,
      votes: 1,
      timeAgo: "just now",
      replies: [],
    }

    // Simulate API call
    setTimeout(() => {
      setComments((prev) => [...prev, comment])
      setNewComment("")
      setIsSubmitting(false)
    }, 1000)
  }

  const handleReply = (commentId: string, replyText: string) => {
    const reply: Comment = {
      id: Date.now().toString(),
      author: "john_doe",
      content: replyText,
      votes: 1,
      timeAgo: "just now",
    }

    setComments((prev) =>
      prev.map((comment) => {
        if (comment.id === commentId) {
          return {
            ...comment,
            replies: [...(comment.replies || []), reply],
          }
        }
        return comment
      }),
    )
  }

  return (
    <Card className="mt-6">
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <MessageSquare className="w-5 h-5 text-gray-500" />
            <span className="font-medium">Comments ({comments.length})</span>
          </div>

          <div className="space-y-3">
            <div className="flex space-x-3">
              <Avatar className="w-8 h-8">
                <AvatarImage src="/placeholder-user.jpg" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <Textarea
                  placeholder="What are your thoughts?"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="min-h-20"
                />
                <div className="flex justify-end mt-2">
                  <Button onClick={handleSubmitComment} disabled={!newComment.trim() || isSubmitting}>
                    {isSubmitting ? "Commenting..." : "Comment"}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t pt-4">
            {comments.map((comment) => (
              <CommentItem key={comment.id} comment={comment} onReply={handleReply} />
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
