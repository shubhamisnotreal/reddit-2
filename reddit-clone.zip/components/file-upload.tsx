"use client"

import type React from "react"

import { useState, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Upload, File, ImageIcon, Video, Folder, Play, Pause, Volume2, VolumeX, Eye, Trash2 } from "lucide-react"

interface FileUploadProps {
  onFilesChange: (files: FileWithPreview[]) => void
  maxFiles?: number
  maxSize?: number // in MB
  acceptedTypes?: string[]
  allowFolders?: boolean
}

interface FileWithPreview {
  file: File
  preview: string
  type: "image" | "video" | "gif" | "other"
  id: string
  uploadProgress?: number
  error?: string
}

export function FileUpload({
  onFilesChange,
  maxFiles = 10,
  maxSize = 100,
  acceptedTypes = ["image/*", "video/*", ".gif"],
  allowFolders = true,
}: FileUploadProps) {
  const [files, setFiles] = useState<FileWithPreview[]>([])
  const [isDragging, setIsDragging] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const folderInputRef = useRef<HTMLInputElement>(null)

  const getFileType = (file: File): "image" | "video" | "gif" | "other" => {
    if (file.type.startsWith("image/")) {
      return file.name.toLowerCase().endsWith(".gif") ? "gif" : "image"
    }
    if (file.type.startsWith("video/")) return "video"
    return "other"
  }

  const createFilePreview = useCallback((file: File): Promise<FileWithPreview> => {
    return new Promise((resolve) => {
      const fileWithPreview: FileWithPreview = {
        file,
        preview: "",
        type: getFileType(file),
        id: Math.random().toString(36).substr(2, 9),
        uploadProgress: 0,
      }

      if (file.type.startsWith("image/") || file.type.startsWith("video/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          fileWithPreview.preview = e.target?.result as string
          resolve(fileWithPreview)
        }
        reader.readAsDataURL(file)
      } else {
        resolve(fileWithPreview)
      }
    })
  }, [])

  const validateFile = (file: File): string | null => {
    // Check file size
    if (file.size > maxSize * 1024 * 1024) {
      return `File size must be less than ${maxSize}MB`
    }

    // Check file type
    const isValidType = acceptedTypes.some((type) => {
      if (type.includes("*")) {
        return file.type.startsWith(type.replace("*", ""))
      }
      return file.name.toLowerCase().endsWith(type)
    })

    if (!isValidType) {
      return `File type not supported. Accepted types: ${acceptedTypes.join(", ")}`
    }

    return null
  }

  const processFiles = async (fileList: FileList) => {
    const newFiles: FileWithPreview[] = []
    const errors: string[] = []

    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i]

      // Skip if we've reached max files
      if (files.length + newFiles.length >= maxFiles) {
        errors.push(`Maximum ${maxFiles} files allowed`)
        break
      }

      const error = validateFile(file)
      if (error) {
        errors.push(`${file.name}: ${error}`)
        continue
      }

      try {
        const fileWithPreview = await createFilePreview(file)
        newFiles.push(fileWithPreview)
      } catch (error) {
        errors.push(`${file.name}: Failed to process file`)
      }
    }

    if (errors.length > 0) {
      // Show errors as toast
      errors.forEach((error) => showToast(error, "error"))
    }

    const updatedFiles = [...files, ...newFiles]
    setFiles(updatedFiles)
    onFilesChange(updatedFiles)
  }

  const showToast = (message: string, type: "success" | "error" | "info" = "info") => {
    const toast = document.createElement("div")
    const bgColor = type === "error" ? "bg-red-500" : type === "success" ? "bg-green-500" : "bg-blue-500"
    toast.className = `fixed top-4 right-4 ${bgColor} text-white px-4 py-2 rounded-lg shadow-lg z-50 transition-all duration-300 max-w-sm`
    toast.textContent = message
    document.body.appendChild(toast)

    setTimeout(() => {
      toast.style.transform = "translateX(100%)"
      toast.style.opacity = "0"
      setTimeout(() => {
        if (document.body.contains(toast)) {
          document.body.removeChild(toast)
        }
      }, 300)
    }, 3000)
  }

  const simulateUpload = (fileId: string) => {
    let progress = 0
    const interval = setInterval(() => {
      progress += Math.random() * 15
      if (progress >= 100) {
        progress = 100
        clearInterval(interval)
        setFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, uploadProgress: 100 } : f)))
        showToast("File uploaded successfully!", "success")
      } else {
        setFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, uploadProgress: progress } : f)))
      }
    }, 200)
  }

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)

      const items = Array.from(e.dataTransfer.items)
      const files: File[] = []

      const processItems = async () => {
        for (const item of items) {
          if (item.kind === "file") {
            const file = item.getAsFile()
            if (file) files.push(file)
          }
        }

        if (files.length > 0) {
          const fileList = new DataTransfer()
          files.forEach((file) => fileList.items.add(file))
          await processFiles(fileList.files)
        }
      }

      processItems()
    },
    [files, maxFiles],
  )

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files
    if (fileList) {
      await processFiles(fileList)
    }
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = ""
    if (folderInputRef.current) folderInputRef.current.value = ""
  }

  const removeFile = (fileId: string) => {
    const updatedFiles = files.filter((f) => f.id !== fileId)
    setFiles(updatedFiles)
    onFilesChange(updatedFiles)
    showToast("File removed", "info")
  }

  const uploadFiles = async () => {
    setIsUploading(true)

    // Simulate upload for each file
    files.forEach((file) => {
      if (file.uploadProgress === undefined || file.uploadProgress < 100) {
        simulateUpload(file.id)
      }
    })

    setTimeout(() => {
      setIsUploading(false)
    }, 3000)
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const getFileIcon = (type: string) => {
    switch (type) {
      case "image":
      case "gif":
        return <ImageIcon className="w-4 h-4" />
      case "video":
        return <Video className="w-4 h-4" />
      default:
        return <File className="w-4 h-4" />
    }
  }

  return (
    <div className="space-y-4">
      {/* Drop Zone */}
      <div
        onDrop={handleDrop}
        onDragOver={(e) => {
          e.preventDefault()
          setIsDragging(true)
        }}
        onDragLeave={() => setIsDragging(false)}
        className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 ${
          isDragging ? "border-orange-400 bg-orange-50" : "border-gray-300 hover:border-orange-400 hover:bg-orange-50"
        }`}
      >
        <div className="space-y-4">
          <div className="flex justify-center">
            <Upload className={`w-12 h-12 ${isDragging ? "text-orange-500" : "text-gray-400"}`} />
          </div>

          <div>
            <p className="text-lg font-medium text-gray-700">
              {isDragging ? "Drop files here" : "Drag and drop files here"}
            </p>
            <p className="text-sm text-gray-500 mt-1">or click to browse from your computer</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              type="button"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center space-x-2"
            >
              <ImageIcon className="w-4 h-4" />
              <span>Choose Files</span>
            </Button>

            {allowFolders && (
              <Button
                type="button"
                variant="outline"
                onClick={() => folderInputRef.current?.click()}
                className="flex items-center space-x-2"
              >
                <Folder className="w-4 h-4" />
                <span>Choose Folder</span>
              </Button>
            )}
          </div>

          <div className="text-xs text-gray-500">
            <p>
              Supported: Images, Videos, GIFs • Max {maxSize}MB per file • Up to {maxFiles} files
            </p>
          </div>
        </div>
      </div>

      {/* Hidden File Inputs */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={acceptedTypes.join(",")}
        onChange={handleFileSelect}
        className="hidden"
      />

      {allowFolders && (
        <input
          ref={folderInputRef}
          type="file"
          multiple
          webkitdirectory=""
          onChange={handleFileSelect}
          className="hidden"
        />
      )}

      {/* File List */}
      {files.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-gray-900">
              Selected Files ({files.length}/{maxFiles})
            </h4>
            {files.length > 0 && (
              <div className="flex space-x-2">
                <Button
                  onClick={uploadFiles}
                  disabled={isUploading}
                  size="sm"
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
                >
                  {isUploading ? "Uploading..." : "Upload All"}
                </Button>
                <Button
                  onClick={() => {
                    setFiles([])
                    onFilesChange([])
                  }}
                  variant="outline"
                  size="sm"
                >
                  Clear All
                </Button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {files.map((fileItem) => (
              <FilePreviewCard
                key={fileItem.id}
                fileItem={fileItem}
                onRemove={() => removeFile(fileItem.id)}
                onUpload={() => simulateUpload(fileItem.id)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// File Preview Card Component
interface FilePreviewCardProps {
  fileItem: FileWithPreview
  onRemove: () => void
  onUpload: () => void
}

function FilePreviewCard({ fileItem, onRemove, onUpload }: FilePreviewCardProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(true)
  const videoRef = useRef<HTMLVideoElement>(null)

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const getFileIcon = (type: string) => {
    switch (type) {
      case "image":
      case "gif":
        return <ImageIcon className="w-4 h-4" />
      case "video":
        return <Video className="w-4 h-4" />
      default:
        return <File className="w-4 h-4" />
    }
  }

  const toggleVideo = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  return (
    <div className="border border-gray-200 rounded-lg p-4 bg-white shadow-sm">
      <div className="flex items-start space-x-3">
        {/* Preview */}
        <div className="flex-shrink-0">
          {fileItem.type === "image" && fileItem.preview && (
            <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-gray-100">
              <img
                src={fileItem.preview || "/placeholder.svg"}
                alt={fileItem.file.name}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          {fileItem.type === "gif" && fileItem.preview && (
            <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-gray-100">
              <img
                src={fileItem.preview || "/placeholder.svg"}
                alt={fileItem.file.name}
                className="w-full h-full object-cover"
              />
              <Badge className="absolute top-1 right-1 text-xs bg-purple-500">GIF</Badge>
            </div>
          )}

          {fileItem.type === "video" && fileItem.preview && (
            <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-gray-100">
              <video
                ref={videoRef}
                src={fileItem.preview}
                className="w-full h-full object-cover"
                muted={isMuted}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={toggleVideo}
                  className="w-8 h-8 rounded-full bg-black/50 text-white hover:bg-black/70"
                >
                  {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                </Button>
              </div>
              <Badge className="absolute top-1 right-1 text-xs bg-red-500">VIDEO</Badge>
            </div>
          )}

          {fileItem.type === "other" && (
            <div className="w-16 h-16 rounded-lg bg-gray-100 flex items-center justify-center">
              {getFileIcon(fileItem.type)}
            </div>
          )}
        </div>

        {/* File Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-gray-900 truncate">{fileItem.file.name}</p>
              <p className="text-xs text-gray-500">{formatFileSize(fileItem.file.size)}</p>

              {fileItem.type === "video" && (
                <div className="flex items-center space-x-2 mt-1">
                  <Button size="sm" variant="ghost" onClick={toggleMute} className="h-6 px-2">
                    {isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                  </Button>
                </div>
              )}
            </div>

            <div className="flex items-center space-x-1 ml-2">
              {fileItem.preview && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => window.open(fileItem.preview, "_blank")}
                  className="h-6 w-6 p-0"
                  title="Preview"
                >
                  <Eye className="w-3 h-3" />
                </Button>
              )}

              <Button
                size="sm"
                variant="ghost"
                onClick={onRemove}
                className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                title="Remove"
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          </div>

          {/* Upload Progress */}
          {fileItem.uploadProgress !== undefined && fileItem.uploadProgress < 100 && (
            <div className="mt-2">
              <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                <span>Uploading...</span>
                <span>{Math.round(fileItem.uploadProgress)}%</span>
              </div>
              <Progress value={fileItem.uploadProgress} className="h-1" />
            </div>
          )}

          {fileItem.uploadProgress === 100 && (
            <div className="mt-2">
              <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                ✓ Uploaded
              </Badge>
            </div>
          )}

          {fileItem.error && (
            <div className="mt-2">
              <Badge variant="destructive" className="text-xs">
                {fileItem.error}
              </Badge>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
