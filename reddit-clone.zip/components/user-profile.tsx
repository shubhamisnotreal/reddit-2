"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PostFeed } from "@/components/post-feed"
import { MessageDialog } from "@/components/message-dialog"
import {
  User,
  MapPin,
  Award,
  MessageSquare,
  ArrowUp,
  Shield,
  Star,
  Trophy,
  Cake,
  Eye,
  Heart,
  Settings,
  Share,
} from "lucide-react"

interface UserProfileProps {
  isOwnProfile?: boolean
}

export function UserProfile({ isOwnProfile = true }: UserProfileProps) {
  const [isFollowing, setIsFollowing] = useState(false)
  const [userPosts, setUserPosts] = useState<any[]>([])
  const [mounted, setMounted] = useState(false)

  const userStats = {
    karma: 247,
    cakeDay: "October 15, 2024",
    posts: 8,
    comments: 34,
    awards: 3,
    followers: 12,
    following: 5,
  }

  const trophies = [
    { name: "Verified Email", icon: "✉️", description: "Verified email address" },
    { name: "New User", icon: "🎂", description: "Welcome to Reddit!" },
    { name: "First Post", icon: "📝", description: "Made your first post" },
    { name: "Helpful", icon: "🙋", description: "Received helpful award" },
  ]

  useEffect(() => {
    setMounted(true)
    // Load user posts from localStorage
    const savedUserPosts = JSON.parse(localStorage.getItem("userPosts") || "[]")
    setUserPosts(savedUserPosts)

    // Update post count
    userStats.posts = savedUserPosts.length
  }, [])

  const handleShare = async () => {
    const profileUrl = `${window.location.origin}/u/john_doe`

    if (navigator.share) {
      try {
        await navigator.share({
          title: "john_doe's Profile",
          text: "Check out this Reddit user profile",
          url: profileUrl,
        })
      } catch (error) {
        // User cancelled sharing
      }
    } else {
      // Fallback to clipboard
      try {
        await navigator.clipboard.writeText(profileUrl)
        showToast("Profile link copied to clipboard!")
      } catch (error) {
        showToast("Failed to copy link", "error")
      }
    }
  }

  const showToast = (message: string, type: "success" | "error" | "info" = "info") => {
    const toast = document.createElement("div")
    const bgColor = type === "error" ? "bg-red-500" : type === "success" ? "bg-green-500" : "bg-blue-500"
    toast.className = `fixed top-4 right-4 ${bgColor} text-white px-4 py-2 rounded-lg shadow-lg z-50 transition-all duration-300`
    toast.textContent = message
    document.body.appendChild(toast)

    setTimeout(() => {
      toast.style.transform = "translateX(100%)"
      toast.style.opacity = "0"
      setTimeout(() => {
        if (document.body.contains(toast)) {
          document.body.removeChild(toast)
        }
      }, 300)
    }, 3000)
  }

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Profile Header */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0 mb-6">
          <div className="relative">
            {/* Cover Image */}
            <div className="h-32 bg-gradient-to-r from-orange-500 via-red-500 to-purple-500 rounded-t-lg"></div>

            {/* Profile Info */}
            <div className="relative px-6 pb-6">
              <div className="flex items-end space-x-4 -mt-16">
                <Avatar className="w-32 h-32 border-4 border-white shadow-xl">
                  <AvatarImage src="/placeholder-user.jpg" />
                  <AvatarFallback className="text-4xl bg-gradient-to-r from-orange-500 to-red-500 text-white">
                    JD
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 pt-16">
                  <div className="flex items-center justify-between">
                    <div>
                      <h1 className="text-3xl font-bold text-gray-900 flex items-center space-x-2">
                        <span>john_doe</span>
                        <Shield className="w-5 h-5 text-blue-500" />
                      </h1>
                      <p className="text-gray-600 mt-1">u/john_doe • {userStats.karma} karma</p>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Cake className="w-4 h-4" />
                          <span>Cake day: {userStats.cakeDay}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <MapPin className="w-4 h-4" />
                          <span>San Francisco, CA</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      {/* Only show Follow button if it's not your own profile */}
                      {!isOwnProfile && (
                        <Button
                          variant={isFollowing ? "outline" : "default"}
                          onClick={() => {
                            setIsFollowing(!isFollowing)
                            showToast(isFollowing ? "Unfollowed user" : "Following user!", "success")
                          }}
                          className={
                            isFollowing
                              ? ""
                              : "bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
                          }
                        >
                          {isFollowing ? "Following" : "Follow"}
                        </Button>
                      )}

                      {/* Show Message button only if it's not your own profile */}
                      {!isOwnProfile && (
                        <MessageDialog recipientUsername="john_doe" recipientDisplayName="john_doe">
                          <Button variant="outline" className="flex items-center space-x-2">
                            <MessageSquare className="w-4 h-4" />
                            <span>Message</span>
                          </Button>
                        </MessageDialog>
                      )}

                      <Button variant="outline" size="icon" onClick={handleShare}>
                        <Share className="w-4 h-4" />
                      </Button>

                      {/* Show Settings button only if it's your own profile */}
                      {isOwnProfile && (
                        <Button variant="outline" size="icon" onClick={() => (window.location.href = "/settings")}>
                          <Settings className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mt-6">
                {[
                  { label: "Post Karma", value: "189", icon: ArrowUp },
                  { label: "Comment Karma", value: "58", icon: MessageSquare },
                  { label: "Awards", value: userStats.awards, icon: Award },
                  { label: "Followers", value: userStats.followers, icon: User },
                  { label: "Following", value: userStats.following, icon: Heart },
                  { label: "Posts", value: userPosts.length, icon: Eye },
                ].map((stat, index) => {
                  const Icon = stat.icon
                  return (
                    <div key={index} className="text-center p-3 bg-gray-50 rounded-lg">
                      <Icon className="w-5 h-5 mx-auto text-gray-600 mb-1" />
                      <div className="font-bold text-lg">{stat.value}</div>
                      <div className="text-xs text-gray-500">{stat.label}</div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="posts" className="space-y-4">
              <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm shadow-lg border-0">
                <TabsTrigger
                  value="posts"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
                >
                  Posts
                </TabsTrigger>
                <TabsTrigger
                  value="comments"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
                >
                  Comments
                </TabsTrigger>
                <TabsTrigger
                  value="saved"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
                >
                  {isOwnProfile ? "Saved" : "Upvoted"}
                </TabsTrigger>
                <TabsTrigger
                  value="awards"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
                >
                  Awards
                </TabsTrigger>
              </TabsList>

              <TabsContent value="posts">
                <div className="space-y-4">
                  <PostFeed posts={userPosts} showUserPosts={true} currentUser="john_doe" sortBy="new" />
                </div>
              </TabsContent>

              <TabsContent value="comments">
                <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
                  <CardContent className="p-6">
                    <p className="text-gray-600 text-center">
                      {isOwnProfile ? "Your comments will be displayed here" : "No comments yet"}
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="saved">
                <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
                  <CardContent className="p-6">
                    <p className="text-gray-600 text-center">
                      {isOwnProfile ? "Saved posts will be displayed here" : "Upvoted posts will be displayed here"}
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="awards">
                <Card className="bg-white/80 backdrop-blur-sm shadow-lg border-0">
                  <CardContent className="p-6">
                    <p className="text-gray-600 text-center">Awards given and received will be displayed here</p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Trophies */}
            <Card className="bg-gradient-to-br from-white to-yellow-50 shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Trophy className="w-5 h-5 text-yellow-500" />
                  <span>Trophies</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {trophies.map((trophy, index) => (
                  <div
                    key={index}
                    className="flex items-center space-x-3 p-2 rounded-lg hover:bg-yellow-50 transition-colors"
                  >
                    <div className="text-2xl">{trophy.icon}</div>
                    <div>
                      <div className="font-medium text-sm">{trophy.name}</div>
                      <div className="text-xs text-gray-500">{trophy.description}</div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Active Communities */}
            <Card className="bg-gradient-to-br from-white to-blue-50 shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Star className="w-5 h-5 text-blue-500" />
                  <span>Active in</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: "reactjs", karma: "89", icon: "⚛️" },
                  { name: "javascript", karma: "67", icon: "🟨" },
                  { name: "webdev", karma: "45", icon: "💻" },
                  { name: "programming", karma: "46", icon: "👨‍💻" },
                ].map((community, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{community.icon}</span>
                      <span className="text-sm font-medium">r/{community.name}</span>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {community.karma} karma
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
