"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MessageSquare, Send } from "lucide-react"

interface MessageDialogProps {
  children: React.ReactNode
  recipientUsername?: string
  recipientDisplayName?: string
}

export function MessageDialog({ children, recipientUsername, recipientDisplayName }: MessageDialogProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [messageData, setMessageData] = useState({
    recipient: recipientUsername || "",
    subject: "",
    message: "",
  })
  const [isSending, setIsSending] = useState(false)

  const handleSendMessage = async () => {
    if (!messageData.recipient.trim() || !messageData.message.trim()) {
      showToast("Please fill in recipient and message", "error")
      return
    }

    setIsSending(true)

    // Simulate sending message
    setTimeout(() => {
      // Add message to localStorage for demo
      const messages = JSON.parse(localStorage.getItem("userMessages") || "[]")
      const newMessage = {
        id: Date.now().toString(),
        from: "john_doe", // Current user
        to: messageData.recipient,
        subject: messageData.subject || "No subject",
        content: messageData.message,
        timestamp: new Date().toISOString(),
        read: false,
      }

      messages.push(newMessage)
      localStorage.setItem("userMessages", JSON.stringify(messages))

      showToast("Message sent successfully!", "success")
      setIsSending(false)
      setIsOpen(false)

      // Reset form
      setMessageData({
        recipient: recipientUsername || "",
        subject: "",
        message: "",
      })
    }, 1000)
  }

  const showToast = (message: string, type: "success" | "error" | "info" = "info") => {
    const toast = document.createElement("div")
    const bgColor = type === "error" ? "bg-red-500" : type === "success" ? "bg-green-500" : "bg-blue-500"
    toast.className = `fixed top-4 right-4 ${bgColor} text-white px-4 py-2 rounded-lg shadow-lg z-50 transition-all duration-300`
    toast.textContent = message
    document.body.appendChild(toast)

    setTimeout(() => {
      toast.style.transform = "translateX(100%)"
      toast.style.opacity = "0"
      setTimeout(() => {
        if (document.body.contains(toast)) {
          document.body.removeChild(toast)
        }
      }, 300)
    }, 3000)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <MessageSquare className="w-5 h-5 text-blue-500" />
            <span>Send Message</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Recipient Info */}
          {recipientUsername && (
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <Avatar className="w-8 h-8">
                <AvatarImage src="/placeholder-user.jpg" />
                <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                  {recipientUsername[0].toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium text-sm">{recipientDisplayName || `u/${recipientUsername}`}</p>
                <p className="text-xs text-gray-500">Recipient</p>
              </div>
            </div>
          )}

          {/* Recipient Input (if not pre-filled) */}
          {!recipientUsername && (
            <div>
              <Label htmlFor="recipient" className="text-sm font-medium">
                To
              </Label>
              <Input
                id="recipient"
                placeholder="Username (e.g., john_doe)"
                value={messageData.recipient}
                onChange={(e) => setMessageData((prev) => ({ ...prev, recipient: e.target.value }))}
                className="mt-1"
              />
            </div>
          )}

          {/* Subject */}
          <div>
            <Label htmlFor="subject" className="text-sm font-medium">
              Subject (optional)
            </Label>
            <Input
              id="subject"
              placeholder="Message subject"
              value={messageData.subject}
              onChange={(e) => setMessageData((prev) => ({ ...prev, subject: e.target.value }))}
              className="mt-1"
            />
          </div>

          {/* Message */}
          <div>
            <Label htmlFor="message" className="text-sm font-medium">
              Message *
            </Label>
            <Textarea
              id="message"
              placeholder="Type your message here..."
              value={messageData.message}
              onChange={(e) => setMessageData((prev) => ({ ...prev, message: e.target.value }))}
              className="mt-1 min-h-24"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleSendMessage}
              disabled={isSending || !messageData.message.trim() || !messageData.recipient.trim()}
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
            >
              {isSending ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send Message
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
