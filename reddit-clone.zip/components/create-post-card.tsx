"use client"

import { useState, useEffect } from "react"
import { ImageIcon, LinkIcon, Video, FileText, BarChart3 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { FileUpload } from "@/components/file-upload"

interface CreatePostCardProps {
  onPostCreate?: (postData: any) => void
}

export function CreatePostCard({ onPostCreate }: CreatePostCardProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [postType, setPostType] = useState<"text" | "image" | "link" | "video" | "poll">("text")

  // Global function to trigger create post from navbar
  useEffect(() => {
    const triggerCreatePost = () => {
      setIsOpen(true)
    }

    // Make function globally available
    ;(window as any).triggerCreatePost = triggerCreatePost

    return () => {
      delete (window as any).triggerCreatePost
    }
  }, [])

  const postTypes = [
    { id: "text", label: "Text", icon: FileText, description: "Share your thoughts" },
    { id: "image", label: "Image & Video", icon: ImageIcon, description: "Share photos or videos" },
    { id: "link", label: "Link", icon: LinkIcon, description: "Share a link" },
    { id: "poll", label: "Poll", icon: BarChart3, description: "Ask the community" },
  ]

  const [formData, setFormData] = useState({
    subreddit: "",
    title: "",
    content: "",
    url: "",
    pollOptions: ["", ""],
    nsfw: false,
    spoiler: false,
    uploadedFiles: [] as any[],
  })

  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async () => {
    if (!formData.title.trim() || !formData.subreddit) {
      alert("Please fill in required fields (title and community)")
      return
    }

    setIsSubmitting(true)

    // Create the post data
    const postData = {
      title: formData.title,
      content: formData.content,
      subreddit: formData.subreddit,
      url: formData.url,
      pollOptions: formData.pollOptions,
      nsfw: formData.nsfw,
      spoiler: formData.spoiler,
      postType: postType,
      // Add image based on post type for demo purposes
      image: getImageForPostType(postType, formData.title),
      flair: getFlairForSubreddit(formData.subreddit),
    }

    // Simulate API call delay
    setTimeout(() => {
      // Call the callback to add the post
      if (onPostCreate) {
        onPostCreate(postData)
      }

      // Show success message
      alert("Post created successfully!")
      setIsSubmitting(false)
      setIsOpen(false)

      // Reset form
      setFormData({
        subreddit: "",
        title: "",
        content: "",
        url: "",
        pollOptions: ["", ""],
        nsfw: false,
        spoiler: false,
        uploadedFiles: [],
      })
      setPostType("text")
    }, 1000)
  }

  // Helper function to get appropriate image based on post type and content
  const getImageForPostType = (type: string, title: string) => {
    if (type === "image") {
      return "/placeholder.svg?height=400&width=600"
    }
    if (type === "link") {
      return "/placeholder.svg?height=300&width=500"
    }
    // For text posts, add image based on keywords in title
    const titleLower = title.toLowerCase()
    if (titleLower.includes("react") || titleLower.includes("app")) {
      return "/images/react-app-dashboard.png"
    }
    if (titleLower.includes("design") || titleLower.includes("ui")) {
      return "/images/mobile-app-mockup.png"
    }
    if (titleLower.includes("game") || titleLower.includes("unity")) {
      return "/images/unity-platformer.png"
    }
    if (titleLower.includes("css") || titleLower.includes("web")) {
      return "/images/css-grid-layout.png"
    }
    return undefined // No image for regular text posts
  }

  // Helper function to get flair based on subreddit
  const getFlairForSubreddit = (subreddit: string) => {
    const flairMap: { [key: string]: string } = {
      reactjs: "Discussion",
      javascript: "Question",
      webdev: "Project",
      programming: "General",
      design: "Feedback",
      gamedev: "Showcase",
      learnprogramming: "Help",
    }
    return flairMap[subreddit] || "General"
  }

  const addPollOption = () => {
    setFormData((prev) => ({
      ...prev,
      pollOptions: [...prev.pollOptions, ""],
    }))
  }

  const updatePollOption = (index: number, value: string) => {
    setFormData((prev) => ({
      ...prev,
      pollOptions: prev.pollOptions.map((option, i) => (i === index ? value : option)),
    }))
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0 hover:shadow-2xl transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-center space-x-4">
          <Avatar className="w-12 h-12 ring-2 ring-orange-200 shadow-md">
            <AvatarImage src="/placeholder-user.jpg" />
            <AvatarFallback className="bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold">
              JD
            </AvatarFallback>
          </Avatar>

          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Input
                data-create-post-trigger
                placeholder="Create Post"
                className="flex-1 cursor-pointer bg-gray-50 hover:bg-gray-100 transition-all duration-200 border-gray-200 focus:border-orange-500 rounded-full py-3 px-6 text-gray-600 hover:shadow-md"
                readOnly
              />
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
                  Create a post
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-6">
                <div>
                  <Label htmlFor="subreddit" className="text-sm font-medium">
                    Choose a community *
                  </Label>
                  <Select
                    value={formData.subreddit}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, subreddit: value }))}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select a subreddit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="reactjs">
                        <div className="flex items-center space-x-2">
                          <span>⚛️</span>
                          <span>r/reactjs</span>
                          <Badge variant="secondary" className="ml-2">
                            2.1M
                          </Badge>
                        </div>
                      </SelectItem>
                      <SelectItem value="javascript">
                        <div className="flex items-center space-x-2">
                          <span>🟨</span>
                          <span>r/javascript</span>
                          <Badge variant="secondary" className="ml-2">
                            3.2M
                          </Badge>
                        </div>
                      </SelectItem>
                      <SelectItem value="webdev">
                        <div className="flex items-center space-x-2">
                          <span>💻</span>
                          <span>r/webdev</span>
                          <Badge variant="secondary" className="ml-2">
                            1.8M
                          </Badge>
                        </div>
                      </SelectItem>
                      <SelectItem value="programming">
                        <div className="flex items-center space-x-2">
                          <span>👨‍💻</span>
                          <span>r/programming</span>
                          <Badge variant="secondary" className="ml-2">
                            4.5M
                          </Badge>
                        </div>
                      </SelectItem>
                      <SelectItem value="design">
                        <div className="flex items-center space-x-2">
                          <span>🎨</span>
                          <span>r/design</span>
                          <Badge variant="secondary" className="ml-2">
                            1.2M
                          </Badge>
                        </div>
                      </SelectItem>
                      <SelectItem value="gamedev">
                        <div className="flex items-center space-x-2">
                          <span>🎮</span>
                          <span>r/gamedev</span>
                          <Badge variant="secondary" className="ml-2">
                            890K
                          </Badge>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {postTypes.map((type) => {
                    const Icon = type.icon
                    return (
                      <Button
                        key={type.id}
                        variant={postType === type.id ? "default" : "outline"}
                        className={`flex flex-col items-center space-y-2 h-auto py-4 transition-all ${
                          postType === type.id
                            ? "bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg"
                            : "hover:bg-orange-50 hover:border-orange-300"
                        }`}
                        onClick={() => setPostType(type.id as any)}
                      >
                        <Icon className="w-5 h-5" />
                        <div className="text-center">
                          <div className="text-sm font-medium">{type.label}</div>
                          <div className="text-xs opacity-70">{type.description}</div>
                        </div>
                      </Button>
                    )
                  })}
                </div>

                <div>
                  <Label htmlFor="title" className="text-sm font-medium">
                    Title *
                  </Label>
                  <Input
                    id="title"
                    placeholder="An interesting title"
                    value={formData.title}
                    onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
                    className="mt-2 focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
                  />
                </div>

                {postType === "text" && (
                  <div>
                    <Label htmlFor="content" className="text-sm font-medium">
                      Text (optional)
                    </Label>
                    <Textarea
                      id="content"
                      placeholder="What are your thoughts?"
                      value={formData.content}
                      onChange={(e) => setFormData((prev) => ({ ...prev, content: e.target.value }))}
                      className="min-h-32 mt-2 focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
                    />
                  </div>
                )}

                {postType === "image" && (
                  <div>
                    <Label htmlFor="image" className="text-sm font-medium">
                      Upload Images, Videos, or GIFs
                    </Label>
                    <FileUpload
                      onFilesChange={(files) => {
                        // Store files for later use
                        setFormData((prev) => ({ ...prev, uploadedFiles: files }))
                      }}
                      maxFiles={5}
                      maxSize={50}
                      acceptedTypes={["image/*", "video/*", ".gif"]}
                      allowFolders={true}
                    />
                  </div>
                )}

                {postType === "link" && (
                  <div>
                    <Label htmlFor="url" className="text-sm font-medium">
                      URL
                    </Label>
                    <Input
                      id="url"
                      placeholder="https://example.com"
                      value={formData.url}
                      onChange={(e) => setFormData((prev) => ({ ...prev, url: e.target.value }))}
                      className="mt-2 focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
                    />
                  </div>
                )}

                {postType === "poll" && (
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium">Poll Options</Label>
                      <div className="space-y-2 mt-2">
                        {formData.pollOptions.map((option, index) => (
                          <Input
                            key={index}
                            placeholder={`Option ${index + 1}`}
                            value={option}
                            onChange={(e) => updatePollOption(index, e.target.value)}
                            className="focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
                          />
                        ))}
                        <Button variant="outline" size="sm" onClick={addPollOption} className="w-full">
                          Add Option
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="flex items-center space-x-4">
                    <Label className="text-sm font-medium">Post Settings</Label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="nsfw"
                        checked={formData.nsfw}
                        onChange={(e) => setFormData((prev) => ({ ...prev, nsfw: e.target.checked }))}
                        className="rounded"
                      />
                      <Label htmlFor="nsfw" className="text-sm">
                        NSFW
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="spoiler"
                        checked={formData.spoiler}
                        onChange={(e) => setFormData((prev) => ({ ...prev, spoiler: e.target.checked }))}
                        className="rounded"
                      />
                      <Label htmlFor="spoiler" className="text-sm">
                        Spoiler
                      </Label>
                    </div>
                  </div>
                  <div className="flex space-x-3">
                    <Button variant="outline" onClick={() => setIsOpen(false)}>
                      Cancel
                    </Button>
                    <Button
                      onClick={handleSubmit}
                      disabled={isSubmitting || !formData.title.trim() || !formData.subreddit}
                      className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 shadow-lg"
                    >
                      {isSubmitting ? "Posting..." : "Post"}
                    </Button>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <div className="flex space-x-2">
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-500 hover:text-orange-600 hover:bg-orange-50 transition-all"
              onClick={() => {
                setPostType("image")
                setIsOpen(true)
              }}
            >
              <ImageIcon className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-500 hover:text-orange-600 hover:bg-orange-50 transition-all"
              onClick={() => {
                setPostType("link")
                setIsOpen(true)
              }}
            >
              <LinkIcon className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-500 hover:text-orange-600 hover:bg-orange-50 transition-all"
              onClick={() => {
                setPostType("video")
                setIsOpen(true)
              }}
            >
              <Video className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
