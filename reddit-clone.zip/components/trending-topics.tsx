"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, ArrowUp, Flame, Zap } from "lucide-react"

export function TrendingTopics() {
  const trendingTopics = [
    { topic: "React 19", posts: "23", trend: "+15%", category: "Tech", hot: true },
    { topic: "AI Development", posts: "18", trend: "+23%", category: "Tech", hot: true },
    { topic: "Web3", posts: "12", trend: "+8%", category: "Crypto", hot: false },
    { topic: "TypeScript", posts: "31", trend: "+12%", category: "Programming", hot: true },
    { topic: "Next.js 15", posts: "9", trend: "+31%", category: "Framework", hot: true },
  ]

  const handleTopicClick = (topic: string) => {
    // Navigate to search results for this topic
    window.location.href = `/search?q=${encodeURIComponent(topic)}`
  }

  return (
    <Card className="bg-gradient-to-br from-white to-orange-50 shadow-xl border-0 overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-orange-200 to-red-200 rounded-full -translate-y-16 translate-x-16 opacity-20"></div>
      <CardHeader className="pb-3 relative">
        <CardTitle className="text-lg flex items-center space-x-2">
          <div className="p-2 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg">
            <TrendingUp className="w-5 h-5 text-white" />
          </div>
          <span className="bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
            Trending Today
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 relative">
        {trendingTopics.map((item, index) => (
          <div
            key={item.topic}
            onClick={() => handleTopicClick(item.topic)}
            className="flex items-center justify-between p-3 rounded-xl hover:bg-white/60 cursor-pointer transition-all hover:shadow-md group"
          >
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <span className="text-sm font-bold text-gray-500 w-4">{index + 1}</span>
                {item.hot && <Flame className="w-3 h-3 text-orange-500" />}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <p className="font-semibold text-sm group-hover:text-orange-600 transition-colors">{item.topic}</p>
                  <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700">
                    {item.category}
                  </Badge>
                </div>
                <p className="text-xs text-gray-500">{item.posts} posts today</p>
              </div>
            </div>
            <Badge
              variant="secondary"
              className="flex items-center space-x-1 text-green-600 bg-green-50 border-green-200"
            >
              <ArrowUp className="w-3 h-3" />
              <span className="text-xs font-bold">{item.trend}</span>
            </Badge>
          </div>
        ))}

        <div className="mt-4 p-3 bg-gradient-to-r from-orange-100 to-red-100 rounded-xl">
          <div className="flex items-center space-x-2 text-orange-700">
            <Zap className="w-4 h-4" />
            <span className="text-sm font-medium">Live trending updates</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
